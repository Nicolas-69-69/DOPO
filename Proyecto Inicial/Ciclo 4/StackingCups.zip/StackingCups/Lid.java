import java.util.ArrayList;

/**
 * Write a description of class Lid here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Lid extends Ceramic{
    private Cup taza;
    
    private Rectangle shape;
    
    public Lid(String color, int width) {
        this.type = "normal";
        this.color = color;
        this.width = width;
        this.height = 1;
        this.position = 0;
        
        canvas_size = Canvas.getSize();
        
        shape = new Rectangle(width * grid,grid,(canvas_size[0]/2) - ((width * grid)/2),canvas_size[1] - (grid * (position + 1)), color);
    }
    
    public Cup findCup(){
        return this.taza;
    }
    
    public Ceramic encuentaLugar(int width) {
        if (contenido.getWidth() > width) {
            return this;
        } else {
            return contenido.encuentaLugar(width);
        }
    }
    
    public void makeVisible() {
        shape.makeVisible();
    }
    
    public void makeInvisible() {
        shape.makeInvisible();
    }
    
    public void changePosition(int position) {
        this.position = position;
        shape.changePlace(canvas_size[1] - (grid * (position + 1)));
    }
    
    public void reset(){
        if (taza != null) {
            taza.taparTaza(null);
        }
        this.contenido = null;
        this.position = 0;
        this.taza = null;
        shape.changeColor(this.color);
    }
    
    public void myCup(Cup taza){
        this.taza = taza;
        shape.changeColor("grey");
    }
}
