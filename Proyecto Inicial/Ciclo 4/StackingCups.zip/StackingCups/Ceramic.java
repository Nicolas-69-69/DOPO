public abstract class Ceramic{
    protected String type = "normal";
    
    protected String color;
    protected int position;
    protected int height;
    protected int width;
    protected Cup contenido;
    
    protected int[] canvas_size;
    
    protected static final int grid = 30;
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
    
    public int getPosition() {
        return position;
    }
    
    public void contenerEn(Cup contenido){
        this.contenido = contenido;
    }
    
    public void changeType(String type){
        this.type = type;
    }
    
    public String getType(){
        return type;
    }
    
    public Cup contenidoEn() {
        return contenido;
    }
    
    public Ceramic contenIn(int height){
        return null;
    }
    
    public abstract void makeVisible();
    public abstract void makeInvisible();
    public abstract void changePosition(int position);
    public abstract void reset();
    public abstract Ceramic encuentaLugar(int width);
}