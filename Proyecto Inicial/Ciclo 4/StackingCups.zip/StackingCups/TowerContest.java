import java.util.*;
import javax.swing.JOptionPane;

/**
 * Write a description of class TowerContest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TowerContest{
    public static String solve(int n, int h){
        String solution = "";
        if (h < (2*n - 1) || h < 1 || n < 1 || h == 2 || h == (n*n) - 2) {
            return "impossible";
        } else if (h == (2*n - 1)) {
            String text = n + "";
            for (int i = n - 1 ; i > 0 ; i--) {
                text += " "+ i;
            }
            return text;
        }
        
        Tower tower = new Tower(n);
        
        for (int i = 1 ; i <= n ; i++) {
            tower.pushCup(i);
        }
        
        if (tower.height() < h) {
            return "impossible";
        }
        
        while (tower.height() != h) {
            if (tower.height() > h) {
                String[][] toSwap = tower.swapToReduce();
                if (toSwap[0] != null && toSwap[1] != null) {
                    tower.swap(toSwap[0],toSwap[1]);
                } else {
                    tower.orderTower();
                }
            } else {
                for (int i = 1 ; i < n ; i++) {
                    int place = 1;
                    
                    while (place > 0){
                        String[][] towerNow = tower.stackingItems();
                        for (int j = 0 ; j < towerNow.length ; j++) {
                            if (towerNow[j][1].equals(i+"")) {
                                place = j;
                                break;
                            }
                        }
                        if (place == 0){
                            break;
                        }
                        tower.swap(towerNow[place],towerNow[place-1]);
                        if (tower.height() == h) {
                            break;
                        }
                    }
                    if (tower.height() == h) {
                        break;
                    }
                }
            }
        }
        
        String[][] stacked = tower.stackingItems();
        for (int i = 0; i < stacked.length; i++) {
            if (i > 0) {
                solution += " ";
            }
            solution += stacked[i][1];
        }
        
        return solution;
    }
    
    public static void simulate(int n, int h){
        String solution = solve(n,h);
        if (solution.equals("impossible")) {
            JOptionPane.showMessageDialog(null, "Error: No es posible simular la solucion");
        } else {
            Tower tower = new Tower(n);
            for (int i = 0; i < solution.length(); i++) {
                char c = solution.charAt(i);
                if (c != ' ') {
                    tower.pushCup(c - '0');
                }
            }
            tower.makeVisible();
        }
    }
}
