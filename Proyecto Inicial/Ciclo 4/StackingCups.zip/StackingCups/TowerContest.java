import java.util.*;
import javax.swing.JOptionPane;

/**
 * Write a description of class TowerContest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TowerContest{
    public static String solve(int n, int h){
        String solution = "";
        if (h < (2*n - 1) || n < 1 || h == (n*n) - 2) {
            return "impossible";
        } else if (h == (2*n - 1)) {
            String text = n + "";
            for (int i = n - 1 ; i > 0 ; i--) {
                text += " "+ i;
            }
            return text;
        }
        
        Tower tower = new Tower(n);
        HashMap<Integer,Integer> tazas = new HashMap<>();
        
        for (int i = 1 ; i <= n ; i++) {
            tazas.put(2*i-1, i);
            tower.pushCup(i);
        }
        
        if (tower.height() < h) {
            return "impossible";
        }
        
        int reaching = h;
        ArrayList<Integer> usingTower = new ArrayList<>();
        
        while (reaching > 0) {
            for (int i = reaching ; i >= 0 ; i--) {
                if (tazas.get(i) != null) {
                    if (!usingTower.contains(i)) {
                        reaching -= i;
                        usingTower.add(i);
                        break;
                    } else if (reaching == 1){
                        break;
                    }
                }
            }
            if (reaching == 1 && usingTower.contains(1)) {
                break;
            }
        }
        
        if (reaching == 0) {
            for (int i = usingTower.size()-1 ; i >= 0 ; i--) {
                tower.pushCup(tazas.get(usingTower.get(i)));
            }
            for (int i = n ; i >= 1 ; i--) {
                if (!usingTower.contains(2*i-1)) {
                    tower.pushCup(i);
                }
            }
        }
        
        while (tower.height() != h) {
            if (tower.height() > h) {
                int getHeight = tower.height();
                int diferent = getHeight - h;
                Integer needed = tazas.get(diferent);
                String[][] theTower = tower.stackingItems();
                
                if (needed != null) {
                    if (Integer.parseInt(theTower[theTower.length -1][1]) == needed){
                        String[][] toSwap = tower.swapToReduce();
                        if (toSwap[0] != null && toSwap[1] != null) {
                            tower.swap(toSwap[0],toSwap[1]);
                        }
                    } else {
                        tower.pushCup(needed);
                    }
                } else {
                    for (int i = diferent ; i > 0 ; i--) {
                        needed = tazas.get(i);
                        if (needed != null) {
                            tower.pushCup(needed);
                        }
                        if (tower.height() < getHeight) {
                            break;
                        } 
                    }
                }
            }
        }
        
        String[][] stacked = tower.stackingItems();
        
        for (int i = 0; i < stacked.length; i++) {
            if (i > 0) {
                solution += " ";
            }
            solution += stacked[i][1];
        }
        
        return solution;
    }
    
    public static void simulate(int n, int h){
        String solution = solve(n,h);
        if (solution.equals("impossible")) {
            JOptionPane.showMessageDialog(null, "Error: No es posible simular la solucion");
        } else {
            
            Tower tower = new Tower(n);
            String[] parts = solution.split(" ");
            for (String s : parts) {
                tower.pushCup(Integer.parseInt(s));
            }
            tower.makeVisible();
        }
    }
    
    public static void test(int tazas){
        int errores = 0;
        for (int i = 1 ; i <= tazas ; i++) {
            int max = 0;
            
            for (int j = 1 ; j <= i ; j++) {
                max += 2*j-1;
            }
            
            for (int j = 2*i-1 ; j < max ; j++) {
                String solution = solve(i,j);
                if (!solution.equals("impossible")) {
                    Tower tower = new Tower(i);
                    String[] parts = solution.split(" ");
                    for (String s : parts) {
                        tower.pushCup(Integer.parseInt(s));
                    }
                    if (tower.height() != j) {
                        System.out.println("[Incorrecto] Taza:"+i+", altura:"+j);
                        errores += 1;
                    } else {
                        System.out.println("[Correcto] Taza:"+i+", altura:"+j);
                    }
                } else {
                    System.out.println("[Sin solucion] Taza:"+i+", altura:"+j);
                }
            }
        }
        
        System.out.println("Finalizado con "+errores+" errores.");
    }
}
