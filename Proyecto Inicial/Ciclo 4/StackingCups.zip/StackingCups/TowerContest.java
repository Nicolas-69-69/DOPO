import java.util.*;
import javax.swing.JOptionPane;

/**
 * Resuelve el problema de la maraton
 *
 * @author Nicolas Delgado y Tatiana Lopez
 * @version 1.0
 */
public class TowerContest{
    private static boolean backtrack(int[] nums, int objetivo, int index, List<Integer> actual) {
        if (objetivo == 0) {
            return true;
        }
        
        if (objetivo < 0 || index >= nums.length) {
            return false;
        }
        
        actual.add(nums[index]);
        if (backtrack(nums, objetivo - nums[index], index + 1, actual)) {
            return true;
        }
        
        actual.remove(actual.size() - 1);
        if (backtrack(nums, objetivo, index + 1, actual)) {
            return true;
        }

        return false;
    }
    
    private static List<Integer> encontrarCombinacion(ArrayList<Integer> nums, int objetivo) {
        List<Integer> resultado = new ArrayList<>();
        int[] arreglo = new int[nums.size()];

        for (int i = 0; i < nums.size(); i++) {
            arreglo[i] = nums.get(i);
        }
        
        if (backtrack(arreglo, objetivo, 0, resultado)) {
            return resultado;
        }
        
        return null;
    }
    
    public static String solve(int n, int h){
        String solution = "";
        
        if (h < (2*n - 1) || n < 1 || h == (n*n) - 2) {
            return "impossible";
        } else if (h == (2*n - 1)) {
            String text = n + "";
            for (int i = n - 1 ; i > 0 ; i--) {
                text += " "+ i;
            }
            return text;
        }
        
        Tower tower = new Tower(n);
        
        HashMap<Integer,Integer> tazas = new HashMap<>();
        ArrayList<Integer> lista = new ArrayList<>();
        
        for (int i = 1 ; i <= n ; i++) {
            tazas.put(2*i-1,i);
            lista.add(2*i-1);
            tower.pushCup(i);
        }
        
        if (tower.height() < h) {
            return "impossible";
        }
        
        ArrayList<Integer> newTower = new ArrayList<>();
        List<Integer> resultado = encontrarCombinacion(lista, h);

        if (resultado == null) {
            return "impossible";
        }
        
        for (Integer num: resultado) {
            newTower.add((num+1)/2);
        }
        
        for (int i = n ; i >= 1 ; i--) {
            if (!newTower.contains(i)){
                newTower.add(i);
            }
        }
        
        for (int i = 0 ; i < newTower.size() ; i++) {
            tower.pushCup(newTower.get(i));
        }
        
        if (tower.height() > h) {
            tower.swap(new String[]{"cup","1"}, new String[]{"cup",n+""});
            
            if (tower.height() != h) {
                for (int i = n ; i >= 1 ; i--) {
                    tower.pushCup(i);
                }
                
                int need = h - tower.height();
                Integer needed = tazas.get(need);
                
                while (needed == null && need > 1) {
                    need -= 1;
                    needed = tazas.get(need);
                }
                
                if (needed != null) {
                    String[][] stacked = tower.stackingItems();
                    tower.pushCup(needed);
                    
                    for (int i = 0; i < stacked.length; i++) {
                        if (Integer.parseInt(stacked[i][1]) != needed) {
                            tower.pushCup(Integer.parseInt(stacked[i][1]));
                        }
                    }
                }
            }      
        }
        
        ArrayList<Integer> cantUse = new ArrayList<>();
        
        while (tower.height() != h) {
            ArrayList<Integer> usedNumbers = new ArrayList<>();
            int reaching = h;
            
            while (reaching > 0) {
                int useNumber = 0;
                for (int i = lista.size() - 1 ; i >= 0 ; i--) {
                    if (lista.get(i) <= reaching && !usedNumbers.contains(lista.get(i)) && !cantUse.contains(lista.get(i))) {
                        useNumber = lista.get(i);
                        usedNumbers.add(useNumber);
                        break;
                    }
                }
                
                if (useNumber == 0) {
                    break;
                }
                
                reaching -= useNumber;
            }
            
            if (usedNumbers.size() == 0) {
                break;
            }
            
            if (usedNumbers.size() > 1) {
                cantUse.add(usedNumbers.get(1));
            }
            
            Collections.sort(usedNumbers);
            
            for (int i = 0 ; i < usedNumbers.size() ; i++) {
                tower.pushCup((usedNumbers.get(i) + 1)/2);
            }
            
            for (int i = n ; i >= 1 ; i--) {
                if (!usedNumbers.contains(2*i-1)) {
                    tower.pushCup(i);
                }
            }
        }
        
        String[][] stacked = tower.stackingItems();
        
        for (int i = 0; i < stacked.length; i++) {
            if (i > 0) {
                solution += " ";
            }
            solution += stacked[i][1];
        }
        
        return solution;
    }
    
    public static void simulate(int n, int h){
        String solution = solve(n,h);
        if (solution.equals("impossible")) {
            JOptionPane.showMessageDialog(null, "Error: No es posible simular la solucion");
        } else {
            
            Tower tower = new Tower(n);
            String[] parts = solution.split(" ");
            for (String s : parts) {
                tower.pushCup(Integer.parseInt(s));
            }
            tower.makeVisible();
        }
    }
    
    public static void test(int tazas){
        int errores = 0;
        for (int i = 1 ; i <= tazas ; i++) {
            int max = 0;
            
            for (int j = 1 ; j <= i ; j++) {
                max += 2*j-1;
            }
            
            for (int j = 2*i-1 ; j <= max ; j++) {
                String solution = solve(i,j);
                
                if (!solution.equals("impossible")) {
                    Tower tower = new Tower(i);
                    String[] parts = solution.split(" ");
                    for (String s : parts) {
                        tower.pushCup(Integer.parseInt(s));
                    }
                    if (tower.height() != j) {
                        System.out.println("[Incorrecto] Taza:"+i+", altura:"+j);
                        errores += 1;
                    } else {
                        //System.out.println("[Correcto] Taza:"+i+", altura:"+j);
                    }
                } else {
                    System.out.println("[Sin solucion] Taza:"+i+", altura:"+j);
                }
            }
        }
        
        System.out.println("Finalizado con "+errores+" errores.");
    }
}
