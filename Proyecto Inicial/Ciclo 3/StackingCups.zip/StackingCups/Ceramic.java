public interface Ceramic{
    int getWidth();
    int getHeight();
    int getPosition();
    void makeVisible();
    void makeInvisible();
    void changePosition(int newPosition);
    Cup contenidoEn();
    void contenerEn(Cup contenido);
    Ceramic encuentaLugar(int width);
    void reset();
}