public interface Ceramic{
    int getWidth();
    int getHeight();
    int getPosition();
    
    void makeVisible();
    void makeInvisible();
    void changePosition(int position);
    void contenerEn(Cup contenido);
    void reset();
    
    Cup contenidoEn();
    Ceramic encuentaLugar(int width);
    
    default Ceramic contenIn(int height){
        return null;
    }
}