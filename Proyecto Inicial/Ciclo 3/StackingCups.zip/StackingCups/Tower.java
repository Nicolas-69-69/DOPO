import java.util.*;
import javax.swing.JOptionPane;

/**
 * Write a description of class Tower here.
 *
 * @author Nicolas Delgado y Tatiana Lopez
 * @version 1.0
 */
public class Tower {
    private int width;
    private int height;
    private int maxHeight;
    private boolean isOk;
    private int n;
    private boolean isVisible;
    
    private static ArrayList<String> colors = new ArrayList<>();
    private HashMap<String,Ceramic> usingCeramic = new HashMap<>();
    private ArrayList<String> mainTower = new ArrayList<>();
    private ArrayList<Rectangle> rule = new ArrayList<>();
    
    private static final int grid = 30;
    
    private void startTower(){
        colors.add("brown");
        colors.add("red");
        colors.add("violet");
        colors.add("orange");
        colors.add("cyan");
        colors.add("pink");
        colors.add("blue");
        colors.add("yellow");
        colors.add("green");
        colors.add("magenta");
        
        for (int i=1 ; i<= n ; i++) {
            usingCeramic.put("taza"+i,new Cup(colors.get(i-1),2*i-1));
            usingCeramic.put("tapa"+i,new Lid(colors.get(i-1),2*i-1));
        }
        
        for (int i = 1 ; i <maxHeight ; i++) {
            Rectangle line = new Rectangle(12,1,0,i*grid,"");
            rule.add(line);
        }
        
        height = 0;
        isVisible = false;
    }
    
    private void canvasSize(int newWidth,int newHeight){
        Canvas.canvasSize(newWidth,newHeight);
    }
    
    private void calculaHeight(){
        int newHeight = 0;
        for (int i = 0 ; i < mainTower.size() ; i++) {
            Ceramic ceramica = usingCeramic.get(mainTower.get(i));
            int j = ceramica.getPosition() + ceramica.getHeight();
            if (j > newHeight) {
                newHeight = j;
            }
        }
        height = newHeight;
    }
    
    private void pushCeramic(int i, String ceramicName){
        Ceramic ceramica = usingCeramic.get(ceramicName);
        
        if (mainTower.size() == 0) {
            mainTower.add(ceramicName);
            ceramica.changePosition(0);
            height = ceramica.getHeight();
        } else {
            Ceramic lastCeramic = usingCeramic.get(mainTower.get(mainTower.size() - 1));
            Ceramic lastContenido = lastCeramic.contenidoEn();
            mainTower.add(ceramicName);
              
            if (lastContenido == null) {
                if (lastCeramic.getWidth() <= ceramica.getWidth() || lastCeramic instanceof Lid) {
                    ceramica.changePosition(lastCeramic.getHeight() + lastCeramic.getPosition());
                    
                    if (ceramica instanceof Lid && lastCeramic instanceof Cup && ceramica.getWidth() == lastCeramic.getWidth()) {
                        Cup tazaTapar = (Cup) lastCeramic;
                        tazaTapar.taparTaza((Lid) ceramica);
                    }
            
                } else {
                    ceramica.changePosition(1 + lastCeramic.getPosition());
                    ceramica.contenerEn((Cup) lastCeramic);
                }
            } else {
                if (lastCeramic.getWidth() > ceramica.getWidth()){
                    ceramica.changePosition(1 + lastCeramic.getPosition());
                    if (lastCeramic instanceof Lid) {
                        ceramica.contenerEn((Cup) lastContenido);
                    } else {
                        ceramica.contenerEn((Cup) lastCeramic);
                    }
                } else {
                    Ceramic ceramicPlace = lastCeramic.encuentaLugar(2*i-1);
                    Ceramic tazaContenido = ceramicPlace.contenidoEn();
                    
                    ceramica.changePosition(ceramicPlace.getHeight() + ceramicPlace.getPosition());
                    
                    if (ceramica instanceof Lid && ceramicPlace instanceof Cup && ceramica.getWidth() == ceramicPlace.getWidth()) {
                        Cup tazaTapar = (Cup) ceramicPlace;
                        tazaTapar.taparTaza((Lid) ceramica);
                    }
                    
                    if (tazaContenido != null) {
                        Ceramic donde = tazaContenido.contenIn(ceramica.getPosition() + ceramica.getHeight());
                        if (donde != null) {
                            ceramica.contenerEn((Cup) donde);
                        }
                    }
                }
            }                    
        }
        calculaHeight();
    }
    
    private void removeCeramic(int i){
        String ceramicName = mainTower.get(i);
        Ceramic ceramic = usingCeramic.get(ceramicName);
        ceramic.makeInvisible();
        ceramic.reset();
        
        ArrayList<String> addition = new ArrayList<>();
        for (int j = i + 1 ; j < mainTower.size() ; j++) {
            addition.add(mainTower.get(j));
            Ceramic c = usingCeramic.get(mainTower.get(j));
            c.reset();
        }
        for (int j = mainTower.size() - 1 ; j >= i ; j--) {
            mainTower.remove(j);
        }
        for (int j = 0 ; j < addition.size() ; j++) {
             Ceramic c = usingCeramic.get(addition.get(j));
             if (c instanceof Cup) {
                 pushCup(addition.get(j).charAt(4) - '0');
             } else {
                 pushLid(addition.get(j).charAt(4) - '0');
             }
        }
        calculaHeight();
    }
    
    private void eliminaTorre(){
        for (int i = 0 ; i < mainTower.size() ; i++) {
            Ceramic ceramic = usingCeramic.get(mainTower.get(i));
            ceramic.reset();
        }
        mainTower.clear();
    }
    
    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;
        
        if (this.width > 19) {
            this.width = 19;
        }
        
        if (this.maxHeight > 29) {
            this.maxHeight = 29;
        }
        
        this.isOk = true;
        this.n = (this.width + 1)/2;
        
        canvasSize(this.width * grid,this.maxHeight * grid);

        startTower();
    }
    
    public Tower(int cups) {
        this.n = cups;
        
        if (this.n > 10) {
            this.n = 10;
        }
        
        this.width = (2 * this.n) - 1;
        this.maxHeight = 29;
        
        canvasSize(width*grid,maxHeight*grid);
        
        startTower();
    }
    
    private void pushCupLid(int i){
        int x =  mainTower.indexOf("taza"+i);
        int y =  mainTower.indexOf("tapa"+i);
                   
        ArrayList<String> a = new ArrayList<>();
        ArrayList<String> b = new ArrayList<>();
        ArrayList<String> c = new ArrayList<>();
                   
        for (int j = 0 ; j < mainTower.size() ; j++) {
            if (j < x) {
                a.add(mainTower.get(j));
            } else if (j >= x && j <= y) {
                b.add(mainTower.get(j));
            } else {
                c.add(mainTower.get(j));
            }
        }
                   
        eliminaTorre();
                   
        for (int j = 0 ; j < a.size() ; j++) {
            pushCeramic(a.get(j).charAt(4) - '0',a.get(j));
        }
        for (int j = 0 ; j < c.size() ; j++) {
            pushCeramic(c.get(j).charAt(4) - '0',c.get(j));
        }
        for (int j = 0 ; j < b.size() ; j++) {
            pushCeramic(b.get(j).charAt(4) - '0',b.get(j));
        }
    }
    
    public void pushCup(int i) {
        String tazaName = "taza"+i;
        
        if (i > 0 && i <= n) {
            isOk = true;
            if (mainTower.contains(tazaName)) {
                Cup ceramica = (Cup) usingCeramic.get(tazaName);
                if (ceramica.findLid() == null) {
                    removeCeramic(mainTower.indexOf(tazaName));
                    pushCeramic(i,tazaName);
                } else {
                   pushCupLid(i);
                }
            } else {
                pushCeramic(i,tazaName);
            }
        } else {
            isOk = false;
            JOptionPane.showMessageDialog(null, "Error: La taza no existe");
        }
        
        if (isVisible && isOk) {
            makeVisible();
        }
    }
    
    public void pushLid(int i) {
        String tapaName = "tapa"+i;
        
        if (i > 0 && i <= n) {
            isOk = true;
            if (mainTower.contains(tapaName)) {
                Lid ceramica = (Lid) usingCeramic.get(tapaName);
                if (ceramica.findCup() == null) {
                    removeCeramic(mainTower.indexOf(tapaName));
                    pushCeramic(i,tapaName);
                } else {
                   pushCupLid(i);
                }
            } else {
                pushCeramic(i,tapaName);
            }
        } else {
            isOk = false;
            JOptionPane.showMessageDialog(null, "Error: La tapa no existe");
        }
        
        if (isVisible && isOk) {
            makeVisible();
        }
    }
    
    public void removeCup(int i) {
        String tazaName = "taza"+i;
        
        if (mainTower.contains(tazaName)) {
            isOk = true;
            removeCeramic(mainTower.indexOf(tazaName));
        } else {
            isOk = false;
            JOptionPane.showMessageDialog(null, "Error: La taza no existe");
        }
        
        if (isVisible && isOk) {
            makeVisible();
        }
    }
    
    public void removeLid(int i) {
        String tapaName = "tapa"+i;
        
        if (mainTower.contains(tapaName)) {
            isOk = true;
            removeCeramic(mainTower.indexOf(tapaName));
        } else {
            isOk = false;
            JOptionPane.showMessageDialog(null, "Error: La tapa no existe");
        }
        
        if (isVisible && isOk) {
            makeVisible();
        }
    }
    
    public void popCup() {
        boolean findC = false;
        
        for (int i = mainTower.size() - 1 ; i >= 0 ; i--) {
            Ceramic ceramic = usingCeramic.get(mainTower.get(i));
            if (ceramic instanceof Cup) {
                findC = true;
                removeCup(mainTower.get(i).charAt(4) - '0');
                break;
            }
        }
        
        if (!findC) {
            isOk = false;
            JOptionPane.showMessageDialog(null, "Error: No se encontro ninguna taza."); 
        }
    }
    
    public void popLid() {
        boolean findC = false;
        
        for (int i = mainTower.size() - 1 ; i >= 0 ; i--) {
            Ceramic ceramic = usingCeramic.get(mainTower.get(i));
            if (ceramic instanceof Lid) {
                findC = true;
                removeLid(mainTower.get(i).charAt(4) - '0');
                break;
            }
        }
        
        if (!findC) {
            isOk = false;
            JOptionPane.showMessageDialog(null, "Error: No se encontro ninguna tapa."); 
        }
    }
    
    public void orderTower() {
        ArrayList<String> copyTower = new ArrayList<>(mainTower);
        
        if (copyTower.size() == 0) {
            isOk = false;
            JOptionPane.showMessageDialog(null, "Error: No hay ceramicas en la torre."); 
        } else {
            isOk = true;
            eliminaTorre();
        
            for(int i=n ; i>0 ; i--){
                Ceramic taza = usingCeramic.get("taza"+i);
                Ceramic tapa = usingCeramic.get("tapa"+i);
                
                if (copyTower.contains("taza"+i)) {
                    pushCup(i);
                }
                if (copyTower.contains("tapa"+i)) {
                    pushLid(i);
                }
            }
        }
    }
    
    public void reverseTower() {
        ArrayList<String> copyTower = new ArrayList<>(mainTower);
        
        if (copyTower.size() == 0) {
            isOk = false;
            JOptionPane.showMessageDialog(null, "Error: No hay ceramicas en la torre."); 
        } else {
            isOk = true;
            eliminaTorre();
        
            for(int i=1 ; i<=n ; i++){
                Ceramic taza = usingCeramic.get("taza"+i);
                Ceramic tapa = usingCeramic.get("tapa"+i);
                
                if (copyTower.contains("taza"+i)) {
                    pushCup(i);
                }
                if (copyTower.contains("tapa"+i)) {
                    pushLid(i);
                }
            }
        }
    }
    
    public void swap(String[] o1, String[] o2) {
        String ceramic1 = "";
        String ceramic2 = "";
        
        if (o1[0] == "cup") {
            ceramic1 = "taza"+o1[1];
        } else if (o1[0] == "lid") {
            ceramic1 = "tapa"+o1[1];
        }
        
        if (o2[0] == "cup") {
            ceramic2 = "taza"+o2[1];
        } else if (o2[0] == "lid") {
            ceramic2 = "tapa"+o2[1];
        }
        
        if (mainTower.contains(ceramic1) && mainTower.contains(ceramic2)) {
            isOk = true;
            Ceramic c1 = usingCeramic.get(ceramic1);
            Ceramic c2 = usingCeramic.get(ceramic2);
            
            int a = -1;
            int b = -1;
            
            // Encuentra las dos posiciones a cambiar
            for (int i = 0 ; i < mainTower.size() ; i++) {
                if (mainTower.get(i).equals(ceramic1) || mainTower.get(i).equals(ceramic2)) {
                    if (a == -1) {
                        a = i;
                    } else {
                        b = i;
                        break;
                    }
                }
            }
            
            if (a >= 0 && b >= 0) {
                ArrayList<String> newTower = new ArrayList<>();
                
                for (int i = a; i < mainTower.size() ; i++) {
                    if (i == a) {
                        newTower.add(mainTower.get(b));
                    } else if (i == b) {
                        newTower.add(mainTower.get(a));
                    } else {
                        newTower.add(mainTower.get(i));
                    }
                }
                
                for (int i = mainTower.size() - 1; i >= a ; i--) {
                    removeCeramic(i);
                }
                
                for (int i = 0 ; i < newTower.size() ; i++) {
                    Ceramic ceramic = usingCeramic.get(newTower.get(i));
                    if (ceramic instanceof Cup) {
                        pushCup(newTower.get(i).charAt(4) - '0');
                    } else {
                        pushLid(newTower.get(i).charAt(4) - '0');
                    }
                }
            }
        } else {
            isOk = false;
            JOptionPane.showMessageDialog(null, "Error: No se encontraron las ceramicas en la torre."); 
        }
    }
    
    public void cover(){
        ArrayList<String> tazas = new ArrayList<>();
        
        for (int i = 0 ; i < mainTower.size() ; i++) {
            int index = mainTower.get(i).charAt(4) - '0';
            
            if (mainTower.get(i).equals("taza"+index) && mainTower.contains("tapa"+index)) {
                tazas.add(mainTower.get(i));
            }
        }
        
        for (int i = tazas.size() - 1 ; i >= 0 ; i--) {
            int id = tazas.get(i).charAt(4) - '0';
            Cup taza = (Cup) usingCeramic.get("taza"+id);
            if (taza.findLid() == null) {
                pushLid(id);
                while (taza.findLid() == null) {
                    int indexTapa = mainTower.indexOf("tapa"+id);
                    if (indexTapa < mainTower.indexOf("taza"+id)) {
                        pushCup(id);
                        pushLid(id);
                    } else {
                        String namePrev = mainTower.get(indexTapa - 1);
                        Ceramic previous = usingCeramic.get(namePrev);
                        if (previous instanceof Cup) {
                            pushCup(namePrev.charAt(4) - '0');
                        } else {
                            pushLid(namePrev.charAt(4) - '0');
                        }
                    } 
                }
            }
        }
    }
    
    public String[][] swapToReduce(){
        int lastHeight = this.height;
        String[] swapA = null;
        String[] swapB = null;
        
        if (mainTower.size() > 1) {
            ArrayList<String> copyTower = new ArrayList<>(mainTower);
            for (int i = 0 ; i < copyTower.size() - 1;i++) {
                String type = "";
                if (copyTower.get(i).substring(0, 4).equals("taza")) {
                    type = "cup";
                } else {
                    type = "lid";
                }
                String[] ceramicA = {type,copyTower.get(i).charAt(4)+""};
                for (int j = i + 1 ; j < copyTower.size(); j++) {
                    if (copyTower.get(j).substring(0, 4).equals("taza")) {
                        type = "cup";
                    } else {
                        type = "lid";
                    }
                    String[] ceramicB = {type,copyTower.get(j).charAt(4)+""};
                    swap(ceramicA,ceramicB);
                    int newHeight = this.height;
                    swap(ceramicB,ceramicA);
                    if (newHeight < lastHeight) {
                        swapA = ceramicA;
                        swapB = ceramicB;
                        break;
                    }
                }
                if (swapA != null) {
                    break;
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Error: Torre sin elementos posibles para cambio");
            isOk = false;
        }
        
        if (isOk && swapA == null) {
            JOptionPane.showMessageDialog(null, "Error: No existe movimiento posible para reducir la altura de la torre");
            isOk = false;
        }
        
        String[][] finalSwap = {swapA,swapB};
        
        return finalSwap;
    }
    
    public int height() {
        return height;
    }
    
    public int[] lidedCups() {
        ArrayList<Integer> lista = new ArrayList<>();
        
        for (int i = 1 ; i <= n ; i++) {
            Ceramic ceramica = usingCeramic.get("taza"+i);
            Cup taza = (Cup) ceramica;
            
            if (taza.findLid() != null) {
                lista.add(i);
            }
        }
        int[] lided = new int[lista.size()];
        
        for (int i = 1 ; i < lista.size() ; i++) {
            lided[i] = lista.get(i);
        }
        
        return lided;
    }
    
    public String[][] stackingItems() {
        String[][] stacked = new String[mainTower.size()][2];
        
        for (int i = 0 ; i < mainTower.size() ; i++) {
            Ceramic ceramica = usingCeramic.get(mainTower.get(i));
            
            if (ceramica instanceof Cup) {
                stacked[i][0] = "cup";
            } else {
                stacked[i][0] = "lid";
            }
            
            stacked[i][1] = String.valueOf(mainTower.get(i).charAt(4));
        }
        
        return stacked;
    }
    
    public void makeVisible() {
        if (height <= maxHeight) {
            for (int i = 1 ; i <= n ; i++) {
                Ceramic taza = usingCeramic.get("taza"+i);
                Ceramic tapa = usingCeramic.get("tapa"+i);
                
                if (mainTower.contains("taza"+i)) {
                    taza.makeVisible();
                } else {
                    taza.makeInvisible();
                }
                
                if (mainTower.contains("tapa"+i)) {
                    tapa.makeVisible();
                } else {
                    tapa.makeInvisible();
                }
            }
            
            for (int i = 0 ; i < rule.size(); i++) {
                Rectangle line = rule.get(i);
                line.makeVisible();
            }
            
            isVisible = true;
            isOk = true;
        } else {
            JOptionPane.showMessageDialog(null, "Error: Torre mas alta del limite");
            isOk = false;
            makeInvisible();
        }
    }
    
    public void makeInvisible() {
        isOk = true;
        isVisible = false;
        for (int i = 1 ; i <= n ; i++) {
            Ceramic taza = usingCeramic.get("taza"+i);
            Ceramic tapa = usingCeramic.get("tapa"+i);
            taza.makeInvisible();
            tapa.makeInvisible();
        }
    }
    
    public void exit() {
        isOk = true;
        Canvas canvas = Canvas.getCanvas();
        canvas.setVisible(false);
    }
    
    public boolean ok() {
        return isOk;
    }
}