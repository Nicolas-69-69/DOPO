import java.util.*;

/**
 * Write a description of class Tower here.
 *
 * @author Nicolas Delgado y Tatiana Lopez
 * @version 1.0
 */
public class Tower {
    private int width;
    private int height;
    private int maxHeight;
    private boolean isOk;
    private int n;
    private boolean isVisible;
    
    private static ArrayList<String> colors = new ArrayList<>();
    private HashMap<String,Ceramic> usingCeramic = new HashMap<>();
    private ArrayList<String> mainTower = new ArrayList<>();
    
    private static final int grid = 30;
    
    private void startTower(){
        colors.add("brown");
        colors.add("red");
        colors.add("violet");
        colors.add("orange");
        colors.add("cyan");
        colors.add("pink");
        colors.add("blue");
        colors.add("yellow");
        colors.add("green");
        colors.add("magenta");
        
        for (int i=1 ; i<= n ; i++) {
            usingCeramic.put("taza"+i,new Cup(colors.get(i-1),2*i-1));
            usingCeramic.put("tapa"+i,new Lid(colors.get(i-1),2*i-1));
        }
        
        height = 0;
        isVisible = false;
    }
    
    private void canvasSize(int newWidth,int newHeight){
        Canvas.canvasSize(newWidth,newHeight);
    }
    
    private void pushCeramic(int i, String ceramicName){
        Ceramic ceramica = usingCeramic.get(ceramicName);
        
        if (mainTower.size() == 0) {
            mainTower.add(ceramicName);
            ceramica.changePosition(0);
            height = ceramica.getHeight();
        } else {
            Ceramic lastCeramic = usingCeramic.get(mainTower.get(mainTower.size() - 1));
            Ceramic lastContenido = lastCeramic.contenidoEn();
            mainTower.add(ceramicName);
              
            if (lastContenido == null) {
                if (lastCeramic.getWidth() <= ceramica.getWidth() || lastCeramic instanceof Lid) {
                    ceramica.changePosition(lastCeramic.getHeight() + lastCeramic.getPosition());
                    height += ceramica.getHeight();
                    
                    if (ceramica instanceof Lid && lastCeramic instanceof Cup && ceramica.getWidth() == lastCeramic.getWidth()) {
                        Cup tazaTapar = (Cup) lastCeramic;
                        tazaTapar.taparTaza((Lid) ceramica);
                    }
            
                } else {
                    ceramica.changePosition(1 + lastCeramic.getPosition());
                    ceramica.contenerEn((Cup) lastCeramic);
                }
            } else {
                if (lastCeramic.getWidth() > ceramica.getWidth()){
                    ceramica.changePosition(1 + lastCeramic.getPosition());
                    if (lastCeramic instanceof Lid) {
                        ceramica.contenerEn((Cup) lastContenido);
                    } else {
                        ceramica.contenerEn((Cup) lastCeramic);
                    }
                } else {
                    Ceramic ceramicPlace = lastCeramic.encuentaLugar(2*i-1);
                    Ceramic tazaContenido = ceramicPlace.contenidoEn();
                    
                    ceramica.changePosition(ceramicPlace.getHeight() + ceramicPlace.getPosition());
                    
                    if (ceramica instanceof Lid && ceramicPlace instanceof Cup && ceramica.getWidth() == ceramicPlace.getWidth()) {
                        Cup tazaTapar = (Cup) ceramicPlace;
                        tazaTapar.taparTaza((Lid) ceramica);
                    }
                    
                    if (tazaContenido != null) {
                        if ((tazaContenido.getPosition() + tazaContenido.getHeight()) > (ceramica.getPosition() + ceramica.getHeight()) ) {
                            ceramica.contenerEn((Cup) tazaContenido);
                        }
                    }
                }
            }                    
        }
    }
    
    private void removeCeramic(int i){
        String ceramicName = mainTower.get(i);
        Ceramic ceramic = usingCeramic.get(ceramicName);
        ceramic.makeInvisible();
        ceramic.reset();
        
        ArrayList<String> addition = new ArrayList<>();
        for (int j = i + 1 ; j < mainTower.size() ; j++) {
            addition.add(mainTower.get(j));
            Ceramic c = usingCeramic.get(mainTower.get(j));
            c.reset();
        }
        for (int j = mainTower.size() - 1 ; j >= i ; j--) {
            mainTower.remove(j);
        }
        for (int j = 0 ; j < addition.size() ; j++) {
             Ceramic c = usingCeramic.get(addition.get(j));
             if (c instanceof Cup) {
                 pushCup(addition.get(j).charAt(4) - '0');
             } else {
                 pushLid(addition.get(j).charAt(4) - '0');
             }
        }
    }
    
    public Tower(int width, int maxHeight)
    {
        this.width = width;
        this.maxHeight = maxHeight;
        
        if (this.width > 19) {
            this.width = 19;
        }
        
        if (this.maxHeight > 29) {
            this.maxHeight = 29;
        }
        
        this.isOk = true;
        this.n = (this.width + 1)/2;
        
        canvasSize(this.width * grid,this.maxHeight * grid);

        startTower();
    }
    
    public Tower(int cups)
    {
        this.n = cups;
        
        if (this.n > 10) {
            this.n = 10;
        }
        
        this.width = (2 * this.n) - 1;
        this.maxHeight = 29;
        
        canvasSize(width*grid,maxHeight*grid);
        
        startTower();
    }
    
    public void pushCup(int i) {
        String tazaName = "taza"+i;
        
        if (i > 0 && i <= n) {
            pushCeramic(i,tazaName);
        }
        
        if (isVisible) {
            makeVisible();
        }
    }
    
    public void pushLid(int i) {
        String tapaName = "tapa"+i;
        
        if (i > 0 && i <= n) {
             pushCeramic(i,tapaName);
        }
        
        if (isVisible) {
            makeVisible();
        }
    }
    
    public void removeCup(int i) {
        String tazaName = "taza"+i;
        
        if (mainTower.contains(tazaName)) {
            removeCeramic(mainTower.indexOf(tazaName));
        }
        
        if (isVisible) {
            makeVisible();
        }
    }
    
    public void removeLid(int i) {
        String tapaName = "tapa"+i;
        
        if (mainTower.contains(tapaName)) {
            removeCeramic(mainTower.indexOf(tapaName));
        }
        
        if (isVisible) {
            makeVisible();
        }
    }
    
    public void popLid() {
        for (int i = mainTower.size() - 1 ; i >= 0 ; i--) {
            Ceramic ceramic = usingCeramic.get(mainTower.get(i));
            if (ceramic instanceof Lid) {
                removeLid(mainTower.get(i).charAt(4) - '0');
                break;
            }
        }
    }
    
    public void popCup() {
        for (int i = mainTower.size() - 1 ; i >= 0 ; i--) {
            Ceramic ceramic = usingCeramic.get(mainTower.get(i));
            if (ceramic instanceof Cup) {
                removeCup(mainTower.get(i).charAt(4) - '0');
                break;
            }
        }
    }
    
    public void orderTower() {
        ArrayList<String> copyTower = new ArrayList<>(mainTower);
        mainTower.clear();
        
        for(int i=n ; i>0 ; i--){
            Ceramic taza = usingCeramic.get("taza"+i);
            Ceramic tapa = usingCeramic.get("tapa"+i);
            taza.reset();
            tapa.reset();
            
            if (copyTower.contains("taza"+i)) {
                pushCup(i);
            }
            if (copyTower.contains("tapa"+i)) {
                pushLid(i);
            }
        }
        
        if (isVisible) {
            makeVisible();
        }
    }
    
    public void reverseTower() {
        ArrayList<String> copyTower = new ArrayList<>(mainTower);
        mainTower.clear();
        
        for(int i=1 ; i<=n ; i++){
            Ceramic taza = usingCeramic.get("taza"+i);
            Ceramic tapa = usingCeramic.get("tapa"+i);
            taza.reset();
            tapa.reset();
            
            if (copyTower.contains("taza"+i)) {
                pushCup(i);
            }
            if (copyTower.contains("tapa"+i)) {
                pushLid(i);
            }
        }
        
        if (isVisible) {
            makeVisible();
        }
    }
    
    public void swap(String[] o1, String[] o2) {
        String ceramic1 = "";
        String ceramic2 = "";
        
        if (o1[0] == "cup") {
            ceramic1 = "taza"+o1[1];
        } else if (o1[0] == "lid") {
            ceramic1 = "tapa"+o1[1];
        }
        
        if (o2[0] == "cup") {
            ceramic2 = "taza"+o2[1];
        } else if (o2[0] == "lid") {
            ceramic2 = "tapa"+o2[1];
        }
        
        if (mainTower.contains(ceramic1) && mainTower.contains(ceramic2)) {
            Ceramic c1 = usingCeramic.get(ceramic1);
            Ceramic c2 = usingCeramic.get(ceramic2);
            
            int a = -1;
            int b = -1;
            
            // Encuentra las dos posiciones a cambiar
            for (int i = 0 ; i < mainTower.size() ; i++) {
                if (mainTower.get(i).equals(ceramic1) || mainTower.get(i).equals(ceramic2)) {
                    if (a == -1) {
                        a = i;
                    } else {
                        b = i;
                        break;
                    }
                }
            }
            
            if (a >= 0 && b >= 0) {
                ArrayList<String> newTower = new ArrayList<>();
                
                for (int i = a; i < mainTower.size() ; i++) {
                    if (i == a) {
                        newTower.add(mainTower.get(b));
                    } else if (i == b) {
                        newTower.add(mainTower.get(a));
                    } else {
                        newTower.add(mainTower.get(i));
                    }
                }
                
                for (int i = mainTower.size() - 1; i >= a ; i--) {
                    removeCeramic(i);
                }
                
                for (int i = 0 ; i < newTower.size() ; i++) {
                    Ceramic ceramic = usingCeramic.get(newTower.get(i));
                    if (ceramic instanceof Cup) {
                        pushCup(newTower.get(i).charAt(4) - '0');
                    } else {
                        pushLid(newTower.get(i).charAt(4) - '0');
                    }
                }
            }
        }
    }
    
    public void cover(){
        ArrayList<String> covering = new ArrayList<>();
        for (int i = 1 ; i <= n ; i++) {
            if (mainTower.contains("taza"+i) && mainTower.contains("tapa"+i)) {
                
            }
        }
    }
    
    public int height() {
        return height;
    }
    
    public int[] lidedCups() {
        ArrayList<Integer> lista = new ArrayList<>();
        
        for (int i = 1 ; i <= n ; i++) {
            Ceramic ceramica = usingCeramic.get("taza"+i);
            Cup taza = (Cup) ceramica;
            
            if (taza.obtenTapa() != null) {
                lista.add(i);
            }
        }
        int[] lided = new int[lista.size()];
        
        for (int i = 1 ; i < lista.size() ; i++) {
            lided[i] = lista.get(i);
        }
        
        return lided;
    }
    
    public String[][] stackingItems() {
        String[][] stacked = new String[mainTower.size()][2];
        
        for (int i = 0 ; i < mainTower.size() ; i++) {
            Ceramic ceramica = usingCeramic.get(mainTower.get(i));
            
            if (ceramica instanceof Cup) {
                stacked[i][0] = "cup";
            } else {
                stacked[i][0] = "lid";
            }
            
            stacked[i][1] = String.valueOf(mainTower.get(i).charAt(4));
        }
        
        return stacked;
    }
    
    public void makeVisible() {
        if (height <= maxHeight) {
            for (int i = 0 ; i < mainTower.size(); i++) {
                Ceramic ceramica = usingCeramic.get(mainTower.get(i));
                ceramica.makeVisible();
            }
            isVisible = true;
        } else {
            makeInvisible();
        }
    }
    
    public void makeInvisible() {
        isVisible = false;
        for (int i = 1 ; i <= n ; i++) {
            Ceramic taza = usingCeramic.get("taza"+i);
            Ceramic tapa = usingCeramic.get("tapa"+i);
            taza.makeInvisible();
            tapa.makeInvisible();
        }
    }
    
    public void exit() {
    }
    
    public boolean ok() {
        return isOk;
    }
}