import java.util.ArrayList;

/**
 * Write a description of class Lid here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Lid implements Ceramic{
    private String color;
    private static final int height = 1;
    private int position;
    private int width;
    private int [] canvas_size;
    private Cup taza;
    private Cup contenido;
    
    private Rectangle shape;
    
    private static final int grid = 30;
    
    public Lid(String color, int width)
    {
        this.color = color;
        this.width = width;
        this.position = 0;
        
        canvas_size = Canvas.getSize();
        
        shape = new Rectangle(width * grid,grid,(canvas_size[0]/2) - ((width * grid)/2),canvas_size[1] - (grid * (position + 1)), color);
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
    
    public int getPosition() {
        return position;
    }
    
    public void makeVisible() {
        shape.makeVisible();
    }
    
    public void makeInvisible() {
        shape.makeInvisible();
    }
    
    public void changePosition(int newPosition) {
        position = newPosition;
        shape.changePlace(canvas_size[1] - (grid * (position + 1)));
    }
    
    public void myCup(Cup taza){
        this.taza = taza;
        shape.changeColor("black");
    }
    
    public Cup contenidoEn() {
        return contenido;
    }
    
    public void contenerEn(Cup contenido){
        this.contenido = contenido;
    }
    
    public Ceramic encuentaLugar(int width) {
        if (contenido.getWidth() > width) {
            return this;
        } else {
            return contenido.encuentaLugar(width);
        }
    }
    
    public void reset(){
        if (taza != null) {
            taza.reset();
        }
        this.contenido = null;
        this.position = 0;
        this.taza = null;
        shape.changeColor(this.color);
    }
}
