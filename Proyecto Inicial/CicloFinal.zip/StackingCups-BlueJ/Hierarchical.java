
/**
 * Write a description of class hierarchical here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Hierarchical extends Cup{
    /**
     * Constructor for objects of class hierarchical
     */
    public Hierarchical(String color, int height) {
        super(color, height);
    }
}