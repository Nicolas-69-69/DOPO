
/**
 * Write a description of class crazy here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Crazy extends Lid{
    /**
     * Constructor for objects of class crazy
     */
    public Crazy(String color, int width) {
        super(color, width);
    }
}
