
/**
 * Write a description of class Shy here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Shy extends Cup{
    /**
     * Constructor for objects of class Shy
     */
    public Shy(String color, int height) {
        super(color, height);
    }
}