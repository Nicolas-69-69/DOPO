
/**
 * Write a description of class fearful here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Fearful extends Lid{
    /**
     * Constructor for objects of class fearful
     */
    public Fearful(String color, int width) {
        super(color, width);
    }
}