
/**
 * Write a description of class opener here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Opener extends Cup{
    public Opener(String color, int height) {
        super(color, height);
    }
}
