class TowerTest{
	public static void main(String[] arg){
    	int tazas = 10;
        int errores = 0;
        for (int i = 1 ; i <= tazas ; i++) {
            int max = 0;
            
            for (int j = 1 ; j <= i ; j++) {
                max += 2*j-1;
            }
            
            for (int j = 2*i-1 ; j <= max ; j++) {
                String solution = TowerContest.solve(i,j);
                
                if (!solution.equals("impossible")) {
                    Tower tower = new Tower(i);
                    String[] parts = solution.split(" ");
                    for (String s : parts) {
                        tower.pushCup(Integer.parseInt(s));
                    }
                    if (tower.height() != j) {
                        System.out.println("[Incorrecto] Taza:"+i+", altura:"+j);
                        errores += 1;
                    } else {
                        //System.out.println("[Correcto] Taza:"+i+", altura:"+j);
                    }
                } else {
                    System.out.println("[Sin solucion] Taza:"+i+", altura:"+j);
                }
            }
        }
        
        System.out.println("Errores: " + errores);
    }
}