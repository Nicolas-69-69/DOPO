import java.util.ArrayList;

/**
 * Write a description of class Cup here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Cup extends Ceramic{
    private Lid tapa;
    
    private ArrayList<Rectangle> shape;
    
    public Cup(String color, int height) {
        this.type = "normal";
        this.color = color;
        this.height = height;
        this.width = height;
        this.position = 0;
        
        shape = new ArrayList<>();
        
        canvas_size = Canvas.getSize();
        
        Rectangle down = new Rectangle(height*grid,grid,(canvas_size[0]/2) - ((height * grid)/2),canvas_size[1] - (grid * (position + 1)),color);
        Rectangle left = new Rectangle(grid,height*grid,down.getPlace()[0],down.getPlace()[1] - ((height - 1) * grid),color);
        Rectangle right = new Rectangle(grid,height*grid,down.getPlace()[0]+ ((height - 1)*grid),down.getPlace()[1] - ((height - 1) * grid),color);
        
        shape.add(down);
        shape.add(left);
        shape.add(right);
    }
    
    public Ceramic encuentaLugar(int width) {
        if (contenido == null) {
            return this;
        } else {
            if (contenido.getWidth() > width) {
                return this;
            } else {
                return contenido.encuentaLugar(width);
            }
        }
    }
    
    public Ceramic contenIn(int height) {
        if (height <= (this.position + this.height)) {
            return this;
        } else {
            if (contenido == null) {
                return null;
            } else {
                return contenido.contenIn(height);
            }
        }
    }
    
    public Lid findLid(){
        return tapa;
    }
    
    public void makeVisible() {
        for (int i = 0; i < shape.size() ; i++) {
            shape.get(i).makeVisible();
        }
    }
    
    public void makeInvisible() {
        for (int i = 0 ; i < shape.size() ; i++) {
            shape.get(i).makeInvisible();
        }
    }
    
    public void changePosition(int position) {
        this.position = position;
        
        Rectangle down = shape.get(0);
        Rectangle left = shape.get(1);
        Rectangle right = shape.get(2);
        
        down.changePlace(canvas_size[1] - (grid * (position + 1)));
        left.changePlace(down.getPlace()[1] - ((height - 1) * grid));
        right.changePlace(down.getPlace()[1] - ((height - 1) * grid));
    }
    
    public void reset(){
        this.contenido = null;
        this.position = 0;
        this.tapa = null;
        for (int i = 0; i < shape.size() ; i++) {
            shape.get(i).changeColor(this.color);
        }
    }
    
    public void taparTaza(Lid tapa){
        this.tapa = tapa;
        if (this.tapa != null) {
            this.tapa.myCup(this);
        
            for (int i = 0; i < shape.size() ; i++) {
                shape.get(i).changeColor("grey");
            }
        } else {
            for (int i = 0; i < shape.size() ; i++) {
                shape.get(i).changeColor(this.color);
            }
        }
    }
}