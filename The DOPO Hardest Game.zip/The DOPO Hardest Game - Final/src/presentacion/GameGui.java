package presentacion;

import dominio.Game;
import dominio.GameException;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

/*
javac -d bin (Get-ChildItem -Recurse src/*.java)
*/

public class GameGui extends JFrame{
    public final int screenX = 900;
    public final int screenY = 690;

    public final String mainFont = "Courier New";
    private final String imagesRute = "/Images/";
    private final String savingFiles = System.getProperty("user.dir") + "/SaveFiles/";

    private Game mainGame;

    // MAIN PANELS
    private JPanel mainMenu, mainBoard, loading, GameOverScreen;

    // TOP BAR
    private JPanel blackBar;
    private JLabel deathsPlayerA, deathsPlayerB, timeLeft, levelDisplay, coinsDisplay;
    private JButton pauseButton, resumeButton, menuButton;

    // LOADING SCREEN
    private JLabel loadingText;

    // MAIN MENU
    private JButton playButton, loadButton;
    private JButton soloButton, PvPButton, PvMButton;
    private JButton backButton;
    private JButton BlinkySelect, InkySelect, ClydeSelect, ChooseColor, RandomMachine, ExpertMachine;

    private JLabel selectIndicator, Blinky, Inky, Clyde, RMachine, EMachine;

    // MAIN BOARD
    private HashMap<String, JLabel> activeObjects;
    private HashMap<String, ImageIcon> imageIcons;
    private HashMap<String, String> mainUrls;

    // ATTRIBUTES
    private File mainFile;
    private String gameMode, skinA, skinB;
    private Color borderA, borderB;
    private Timer fps;

    private int xA, xB, yA, yB;
    private int coins, enemies, lifeFountains, bombs;
    
    private final String[] playableSkins = new String[] {"Red","Blue","Green","Expert","Random"};
    
    private void setFile() {
    	try {
    		if (mainFile == null) {
    			JFileChooser chooser = new JFileChooser();
        	    chooser.setCurrentDirectory(new File(savingFiles));
                chooser.setFileFilter(new FileNameExtensionFilter("DAT files","dat"));
                int archivo = chooser.showSaveDialog(null);
                        
                if (archivo == JFileChooser.APPROVE_OPTION) {
                    File file = chooser.getSelectedFile();
                    if (!file.getName().endsWith(".dat")) {
                        file = new File(file.getAbsolutePath() + ".dat");
                        mainFile = file;
                    }
                }
    		}
    		
            if (mainFile == null) {
            	mainFile = new File(savingFiles + "AutomaticSave.dat");
        		mainFile.getParentFile().mkdirs();
        		
        	    if (!mainFile.exists()) {
        	    	mainFile.createNewFile();
        	    }
            }
    	    
    	    try (BufferedWriter bw = new BufferedWriter(new FileWriter(mainFile))) {
    	    	if (borderA != null) {
    	    		bw.write("borderA=" + borderA.getRed() + "," + borderA.getGreen() + "," + borderA.getBlue());
    	    	} else {
    	    		bw.write("borderA=" + borderA);
    	    	}
        		bw.newLine();
        		if (borderB != null) {
    	    		bw.write("borderB=" + borderB.getRed() + "," + borderB.getGreen() + "," + borderB.getBlue());
    	    	} else {
    	    		bw.write("borderB=" + borderB);
    	    	}
        	    bw.newLine();
        	}
    	} catch (IOException e) {}
    }

    private GameGui(){
        prepareElements();
        prepareActions();
    }

    public static void main(String[] args) {
        GameGui gui = new GameGui();
        gui.setVisible(true);
    }

    private void prepareElements(){
        setTitle("TheDOPOHardestGame");
        setSize(screenX,screenY);
        setResizable(false);
        setLayout(null);
        getContentPane().setBackground(new Color(180, 240, 240));

        imageIcons = new HashMap<>();

        prepareGameOver();
        prepareTopBar();
        prepareMenu();
        prepareLoading();
    }

    private void prepareActions(){
        xA = 0;
        xB = 0;
        yA = 0;
        yB = 0;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        fps = new Timer(16, e -> {
            if (mainGame.completedBoard()){
                fps.stop();
                startGame(mainGame.getLevel() + 1);
            } else {
                moveBoard();
            }
        });

        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int keyCode = e.getKeyCode();
                // PLAYER A
                if ((keyCode == 37 || keyCode == 39) && xA == 0) {
                    if (keyCode == 37) {
                        xA = -1;
                    } else {
                        xA = 1;
                    }
                }
                if ((keyCode == 38 || keyCode == 40) && yA == 0) {
                    if (keyCode == 38) {
                        yA = -1;
                    } else {
                        yA = 1;
                    }
                }

                // PLAYER B
                if ((keyCode == 65 || keyCode == 68) && xB == 0) {
                    if (keyCode == 65) {
                        xB = -1;
                    } else {
                        xB = 1;
                    }
                }
                if ((keyCode == 87 || keyCode == 83) && yB == 0) {
                    if (keyCode == 87) {
                        yB = -1;
                    } else {
                        yB = 1;
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                int keyCode = e.getKeyCode();
                // PLAYER A
                if (keyCode == 37 && xA == -1) {
                    xA = 0;
                } else if (keyCode == 39 && xA == 1) {
                    xA = 0;
                }
                if (keyCode == 38 && yA == -1) {
                    yA = 0;
                } else if (keyCode == 40 && yA == 1) {
                    yA = 0;
                }
                // PLAYER B
                if (keyCode == 65 && xB == -1) {
                    xB = 0;
                } else if (keyCode == 68 && xB == 1) {
                    xB = 0;
                }
                if (keyCode == 87 && yB == -1) {
                    yB = 0;
                } else if (keyCode == 83 && yB == 1) {
                    yB = 0;
                }
            }
        });

        playButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    opcionesJugables();
                }
            });

        loadButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    loadLevel();
                }
            });

        backButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    retrocederMenu();
                }
            });

        // GAME MODES
        soloButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    gameMode = "Solo";
                    characterSelection();
                }
            });

        PvPButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    gameMode = "PvP";
                    characterSelection();
                }
            });

        PvMButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    gameMode = "PvM";
                    characterSelection();
                }
            });
        
        // CHARACTERS
        BlinkySelect.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    selectCharacter(playableSkins[0]);
                }
            });

        InkySelect.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    selectCharacter(playableSkins[1]);
                }
            });

        ClydeSelect.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    selectCharacter(playableSkins[2]);
                }
            });
        ChooseColor.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    selectColor();
                }
            });
        RandomMachine.addActionListener(
                new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e){
                    	selectCharacter(playableSkins[3]);
                    }
                });
        ExpertMachine.addActionListener(
                new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e){
                       selectCharacter(playableSkins[4]);
                    }
                });
        pauseButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    pauseGame();
                }
            });
        resumeButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    resumeGame();
                }
            });
        menuButton.addActionListener(
            new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e){
                    DisplayMenu();
                }
            });
    }

    private void loadLevel() {
        try {
            JFileChooser chooser = new JFileChooser();
            chooser.setCurrentDirectory(new File(savingFiles));
            chooser.setFileFilter(new FileNameExtensionFilter("DAT files","dat"));
            int archivo = chooser.showOpenDialog(null);
                    
            if (archivo == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                
                try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                    String linea;
                    Integer savedLevel = 1, savedDeathsA = 0 , savedDeathsB = 0;
                    String savedSkinA = "", savedSkinB = "";
                    Color savedBorderA = new Color(255,255,0), savedBorderB = new Color(0,255,255);
                    
                    while ((linea = br.readLine()) != null) {
                    	String[] saveDat = linea.split("=");
                    	
                    	if (saveDat[0].equals("level")) {
                    		try {
                    			savedLevel = Integer.parseInt(saveDat[1]);
                    		} catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    			savedLevel = 1;
                    		}
                    	} else if (saveDat[0].equals("skinA")) {
                    		try {
                    			savedSkinA = saveDat[1];
                    		} catch (ArrayIndexOutOfBoundsException e) {
                    			savedSkinA = "";
                    		}
                    	} else if (saveDat[0].equals("skinB")) {
                    		try {
                    			savedSkinB = saveDat[1];
                    		} catch (ArrayIndexOutOfBoundsException e) {
                    			savedSkinB = "";
                    		}
                    	} else if (saveDat[0].equals("deathsA")) {
                    		try {
                    			savedDeathsA = Integer.parseInt(saveDat[1]);
                    		} catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    			savedDeathsA = 0;
                    		}
                    	} else if (saveDat[0].equals("deathsB")) {
                    		try {
                    			savedDeathsB = Integer.parseInt(saveDat[1]);
                    		} catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    			savedDeathsB = 0;
                    		}
                    	}  else if (saveDat[0].equals("borderA")) {
                    		try {
                    			String[] color = saveDat[1].split(",");
                        		try {
                        			savedBorderA = new Color(Integer.parseInt(color[0]),
                        					Integer.parseInt(color[1]),Integer.parseInt(color[2]));
                        		} catch (NumberFormatException e) {
                        			savedBorderA = null;
                        		}
                    		} catch (ArrayIndexOutOfBoundsException e) {
                    			savedBorderA = null;
                    		}
                    	} else if (saveDat[0].equals("borderB")) {
                    		try {
                    			String[] color = saveDat[1].split(",");
                        		try {
                        			savedBorderB = new Color(Integer.parseInt(color[0]),
                        					Integer.parseInt(color[1]),Integer.parseInt(color[2]));
                        		} catch (NumberFormatException e) {
                        			savedBorderB = null;
                        		}
                    		} catch (ArrayIndexOutOfBoundsException e) {
                    			savedBorderB = null;
                    		}
                    	} 
                    }
                    
                    if (savedSkinA.equals("") || !Arrays.asList(playableSkins).contains(savedSkinA)) {
                    	savedSkinA = playableSkins[0];
                    }
                    
                    if (!savedSkinB.equals("") && !Arrays.asList(playableSkins).contains(savedSkinB)) {
                    	savedSkinB = playableSkins[0];
                    }
                    
                    if (savedSkinB.equals("")) {
                    	savedBorderB = null;
                    }
                    
                    if (savedBorderA == null && !savedSkinB.equals("")) {
                    	savedBorderA = new Color(0,0,0);
                    } else if (savedBorderA != null && savedSkinB.equals("")) {
                    	savedBorderA = null;
                    }
                    
                    if (savedBorderB == null && !savedSkinB.equals("")) {
                    	savedBorderB = savedBorderA;
                    }
                    
                    Random rand = new Random();
                    
                    if (savedBorderA != null) {
                    	while (savedBorderA.equals(new Color(0,0,0))) {
                        	savedBorderA = new Color(rand.nextInt(50, 256),rand.nextInt(50, 256),rand.nextInt(50, 256));
                        }
                    }
                    
                    if (savedBorderB != null) {
                    	while (savedBorderA.equals(savedBorderB) || savedBorderB.equals(new Color(0,0,0))) {
                        	savedBorderB = new Color(rand.nextInt(50, 256),rand.nextInt(50, 256),rand.nextInt(50, 256));
                        }
                    }
                    
                    skinA = savedSkinA;
                    skinB = savedSkinB;
                    
                    borderA = savedBorderA;
                    borderB = savedBorderB;

                    mainGame.setDeaths(savedDeathsA, savedDeathsB);
                    
                    mainFile = file;
                    
                    startGame(savedLevel);
                }
            }
        } catch (IOException e) {
        	String message = GameException.ERROR_FILE;
        	
        	JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void pauseGame(){
        pauseButton.setVisible(false);
        mainGame.stopTimer();
        fps.stop();
        resumeButton.setVisible(true);
    }

    private void resumeGame(){
        pauseButton.setVisible(true);
        mainGame.resumeTimer();
        fps.start();
        resumeButton.setVisible(false);
    }

    private void buttonsStyle(JButton b, Color color){
        b.setFont(new Font(mainFont, Font.PLAIN, 20));
        b.setBackground(Color.BLACK);
        b.setForeground(color);
        b.setFocusable(false);
        b.setBorder(BorderFactory.createLineBorder(color, 1));
    }

    private void prepareTopBar(){
        blackBar = new JPanel();
        blackBar.setBounds(0, 0, screenX, 70);
        blackBar.setBackground(Color.BLACK);
        blackBar.setVisible(false);
        blackBar.setLayout(null);

        deathsPlayerA = new JLabel();
        deathsPlayerA.setForeground(Color.WHITE);
        deathsPlayerA.setFont(new Font(mainFont, Font.BOLD, 20));
        deathsPlayerA.setHorizontalAlignment(JLabel.CENTER);
        deathsPlayerA.setText("DEATHS: 0");
        deathsPlayerA.setBounds(5, 20, 140, 30);

        deathsPlayerB = new JLabel();
        deathsPlayerB.setBounds(5, 35, 250, 30);
        deathsPlayerB.setForeground(Color.WHITE);
        deathsPlayerB.setFont(new Font(mainFont, Font.BOLD, 20));
        deathsPlayerB.setHorizontalAlignment(JLabel.CENTER);
        deathsPlayerB.setText("DEATHS PLAYER 2: 0");
        deathsPlayerB.setVisible(false);

        timeLeft = new JLabel();
        timeLeft.setBounds(screenX/2 - 60, 10, 50, 30);
        timeLeft.setForeground(Color.WHITE);
        timeLeft.setFont(new Font(mainFont, Font.BOLD, 20));
        timeLeft.setHorizontalAlignment(JLabel.RIGHT);
        timeLeft.setText("5:00");

        ImageIcon pauseIcon = new ImageIcon(getClass().getResource(imagesRute+"Pause.png"));
        Image pauseImage = pauseIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);

        ImageIcon resumeIcon = new ImageIcon(getClass().getResource(imagesRute+"Continue.png"));
        Image resumeImage = resumeIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);

        pauseButton = new JButton(new ImageIcon(pauseImage));
        pauseButton.setBounds(screenX/2 + 10, 15, 20, 20);
        pauseButton.setFocusable(false);
        pauseButton.setContentAreaFilled(false);
        pauseButton.setBorderPainted(false);
        
        resumeButton = new JButton(new ImageIcon(resumeImage));
        resumeButton.setBounds(screenX/2 + 10, 15, 20, 20);
        resumeButton.setFocusable(false);
        resumeButton.setContentAreaFilled(false);
        resumeButton.setVisible(false);
        resumeButton.setBorderPainted(false);

        levelDisplay = new JLabel();
        levelDisplay.setBounds(screenX/2 - 25, 40, 50, 25);
        levelDisplay.setForeground(Color.WHITE);
        levelDisplay.setFont(new Font(mainFont, Font.BOLD, 18));
        levelDisplay.setHorizontalAlignment(JLabel.CENTER);
        levelDisplay.setText("1/3");

        coinsDisplay = new JLabel();
        coinsDisplay.setBounds(screenX - 175, 40, 140, 25);
        coinsDisplay.setForeground(Color.WHITE);
        coinsDisplay.setFont(new Font(mainFont, Font.BOLD, 20));
        coinsDisplay.setHorizontalAlignment(JLabel.RIGHT);
        coinsDisplay.setText("COINS: 1/10");

        menuButton = new JButton("MENU");
        menuButton.setBounds(screenX - 160, 10, 140, 25);
        menuButton.setFocusable(false);
        menuButton.setContentAreaFilled(false);
        menuButton.setBorderPainted(false);
        menuButton.setForeground(Color.WHITE);
        menuButton.setHorizontalAlignment(JLabel.RIGHT);
        menuButton.setFont(new Font(mainFont, Font.BOLD, 20));

        blackBar.add(deathsPlayerA);
        blackBar.add(deathsPlayerB);
        blackBar.add(timeLeft);
        blackBar.add(levelDisplay);
        blackBar.add(pauseButton);
        blackBar.add(resumeButton);
        blackBar.add(menuButton);
        blackBar.add(coinsDisplay);

        add(blackBar);
    }

    private void prepareGameOver(){
        GameOverScreen = new JPanel();
        GameOverScreen.setBounds(0, 0, screenX, screenY);
        GameOverScreen.setBackground(Color.BLACK);
        GameOverScreen.setLayout(null);

        JLabel GameOverText = new JLabel();
        GameOverText.setBounds(screenX/2 - 250, screenY/2 - 50, 500, 100);
        GameOverText.setText("GAME OVER");
        GameOverText.setForeground(Color.RED);
        GameOverText.setFont(new Font(mainFont, Font.BOLD, 40));
        GameOverText.setHorizontalAlignment(JLabel.CENTER);

        GameOverScreen.add(GameOverText);
        GameOverScreen.setVisible(false);

        add(GameOverScreen);
    }

    private void prepareMenu(){
        mainMenu = new JPanel();
        mainMenu.setBounds(0, 0, screenX, screenY);
        mainMenu.setBackground(Color.BLACK);
        mainMenu.setLayout(null);

        // DECORATIONS
        JLabel ver = new JLabel();
        JLabel creator = new JLabel();
        JLabel tittle = new JLabel();
        selectIndicator = new JLabel();

        ImageIcon icon = new ImageIcon(getClass().getResource(imagesRute+"GameTittle.png"));
        Image img = icon.getImage().getScaledInstance(550, 200, Image.SCALE_SMOOTH);
        tittle.setIcon(new ImageIcon(img));
        tittle.setBounds(screenX/2 - 275, 10, 550, 200);

        ver.setBounds(10, screenY - 70, 50, 25);
        ver.setText("1.0");
        ver.setForeground(Color.WHITE);
        ver.setFont(new Font(mainFont, Font.BOLD, 15));

        creator.setBounds(screenX - 200, screenY - 70, 200, 25);
        creator.setText("2026 Nicolas Delgado");
        creator.setForeground(Color.WHITE);
        creator.setFont(new Font(mainFont, Font.BOLD, 15));

        selectIndicator.setBounds(screenX/2 - 250, screenY/2 - 40, 500, 25);
        selectIndicator.setForeground(Color.WHITE);
        selectIndicator.setFont(new Font(mainFont, Font.BOLD, 15));
        selectIndicator.setHorizontalAlignment(JLabel.CENTER);

        // BUTTONS
        playButton = new JButton("PLAY");
        loadButton = new JButton("LOAD");
        soloButton = new JButton("SOLO");
        PvPButton = new JButton("PLAYER VS PLAYER");
        PvMButton = new JButton("PLAYER VS MACHINE");
        backButton = new JButton("BACK");

        // GAME MODE
        ImageIcon redIcon = new ImageIcon(getClass().getResource(imagesRute + "Player/Red/Normal.png"));
        Image redImage = redIcon.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);

        ImageIcon blueIcon = new ImageIcon(getClass().getResource(imagesRute + "Player/Blue/Normal.png"));
        Image blueImage = blueIcon.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);

        ImageIcon greenIcon = new ImageIcon(getClass().getResource(imagesRute + "Player/Green/Normal.png"));
        Image greenImage = greenIcon.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);

        ImageIcon machineIcon = new ImageIcon(getClass().getResource(imagesRute + "Player/Bot/Normal.png"));
        Image machineImage = machineIcon.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);

        BlinkySelect = new JButton(new ImageIcon(redImage));
        InkySelect = new JButton(new ImageIcon(blueImage));
        ClydeSelect = new JButton(new ImageIcon(greenImage));
        RandomMachine = new JButton(new ImageIcon(machineImage));
        ExpertMachine = new JButton(new ImageIcon(machineImage));
        ChooseColor = new JButton();

        Blinky = new JLabel();
        Blinky.setBounds(screenX/2 - 120, screenY/2, 70, 20);
        Blinky.setText("Blinky");
        Blinky.setForeground(Color.WHITE);
        Blinky.setFont(new Font(mainFont, Font.BOLD, 15));
        Blinky.setHorizontalAlignment(JLabel.CENTER);

        Inky = new JLabel();
        Inky.setBounds(screenX/2 - 35, screenY/2, 70, 20);
        Inky.setText("Inky");
        Inky.setForeground(Color.WHITE);
        Inky.setFont(new Font(mainFont, Font.BOLD, 15));
        Inky.setHorizontalAlignment(JLabel.CENTER);

        Clyde = new JLabel();
        Clyde.setBounds(screenX/2 + 50, screenY/2, 70, 20);
        Clyde.setText("Clyde");
        Clyde.setForeground(Color.WHITE);
        Clyde.setFont(new Font(mainFont, Font.BOLD, 15));
        Clyde.setHorizontalAlignment(JLabel.CENTER);

        RMachine = new JLabel();
        RMachine.setBounds(screenX/2 + 10, screenY/2, 70, 20);
        RMachine.setText("Random");
        RMachine.setForeground(Color.WHITE);
        RMachine.setFont(new Font(mainFont, Font.BOLD, 15));
        RMachine.setHorizontalAlignment(JLabel.CENTER);

        EMachine = new JLabel();
        EMachine.setBounds(screenX/2 - 80, screenY/2, 70, 20);
        EMachine.setText("Expert");
        EMachine.setForeground(Color.WHITE);
        EMachine.setFont(new Font(mainFont, Font.BOLD, 15));
        EMachine.setHorizontalAlignment(JLabel.CENTER);

        buttonsStyle(playButton,Color.RED);
        buttonsStyle(loadButton, Color.BLUE);
        buttonsStyle(soloButton,Color.CYAN);
        buttonsStyle(PvPButton,Color.MAGENTA);
        buttonsStyle(PvMButton,Color.ORANGE);
        buttonsStyle(backButton,Color.GRAY);
        buttonsStyle(BlinkySelect,Color.BLACK);
        buttonsStyle(InkySelect,Color.BLACK);
        buttonsStyle(ClydeSelect,Color.BLACK);
        buttonsStyle(RandomMachine,Color.BLACK);
        buttonsStyle(ExpertMachine,Color.BLACK);

        ChooseColor.setBackground(Color.BLACK);
        ChooseColor.setFocusable(false);
        ChooseColor.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));

        playButton.setBounds(screenX/2 - 125, screenY/2, 250, 25);
        loadButton.setBounds(screenX/2 - 125, screenY/2 + 30, 250, 25);
        soloButton.setBounds(screenX/2 - 125, screenY/2, 250, 25);
        PvPButton.setBounds(screenX/2 - 125, screenY/2 + 30, 250, 25);
        PvMButton.setBounds(screenX/2 - 125, screenY/2 + 60, 250, 25);
        backButton.setBounds(screenX/2 - 125, screenY/2 + 120, 250, 25);
        ChooseColor.setBounds(screenX/2 + 130, screenY/2 + 35, 30, 30);
        BlinkySelect.setBounds(screenX/2 - 120, screenY/2 + 30, 70, 70);
        InkySelect.setBounds(screenX/2 - 35, screenY/2 + 30, 70, 70);
        ClydeSelect.setBounds(screenX/2 + 50, screenY/2 + 30, 70, 70);
        ExpertMachine.setBounds(screenX/2 + 10, screenY/2 + 30, 70, 70);
        RandomMachine.setBounds(screenX/2 - 80, screenY/2 + 30, 70, 70);

        mainMenu.add(playButton);
        mainMenu.add(loadButton);
        mainMenu.add(soloButton);
        mainMenu.add(PvPButton);
        mainMenu.add(PvMButton);
        mainMenu.add(backButton);
        mainMenu.add(ver);
        mainMenu.add(tittle);
        mainMenu.add(creator);
        mainMenu.add(selectIndicator);
        mainMenu.add(ChooseColor);
        mainMenu.add(BlinkySelect);
        mainMenu.add(InkySelect);
        mainMenu.add(ClydeSelect);
        mainMenu.add(ExpertMachine);
        mainMenu.add(RandomMachine);
        mainMenu.add(Blinky);
        mainMenu.add(Inky);
        mainMenu.add(Clyde);
        mainMenu.add(EMachine);
        mainMenu.add(RMachine);

        showMenu();

        add(mainMenu);
    }

    private void showMenu(){
    	mainGame = new Game(screenX, screenY);
    	
        gameMode = "";
        skinA = "";
        skinB = "";
        borderA = null;
        borderB = null;
        
        blackBar.setVisible(false);
        playButton.setVisible(true);
        loadButton.setVisible(true);
        soloButton.setVisible(false);
        PvPButton.setVisible(false);
        PvMButton.setVisible(false);
        backButton.setVisible(false);
        ChooseColor.setVisible(false);
        BlinkySelect.setVisible(false);
        InkySelect.setVisible(false);
        ClydeSelect.setVisible(false);
        selectIndicator.setVisible(false);
        RandomMachine.setVisible(false);
        ExpertMachine.setVisible(false);
        Blinky.setVisible(false);
        Inky.setVisible(false);
        Clyde.setVisible(false);
        EMachine.setVisible(false);
        RMachine.setVisible(false);

        pauseButton.setVisible(true);
        resumeButton.setVisible(false);

        mainMenu.setVisible(true);
    }

    private void prepareLoading(){
        loading = new JPanel();
        loading.setBounds(0, 0, screenX, screenY);
        loading.setBackground(Color.BLACK);
        loading.setLayout(null); 

        loadingText = new JLabel();

        loadingText.setBounds(50, 25, screenX - 100, screenY - 50);
        loadingText.setText("Loading...");
        loadingText.setForeground(Color.WHITE);
        loadingText.setFont(new Font(mainFont, Font.BOLD, 20));
        loadingText.setHorizontalAlignment(JLabel.CENTER);

        loading.add(loadingText);
        add(loading);
        loading.setVisible(false);
    }

    private void loadingScreen(){
        int num = (int)(Math.random() * 11) + 1;

        switch (num) {
            case 1 -> loadingText.setText("Es mas dificil esto o pasar DOPO?");
            case 2 -> loadingText.setText("Cuantas muertes llevas?");
            case 3 -> loadingText.setText("01001101 01010101 01000101 01010010 01010100 01000101");
            case 4 -> loadingText.setText("Es mas estresante jugar o desarrollar el juego?");
            case 5 -> loadingText.setText("<Inserte frase divertida>");
            case 6 -> loadingText.setText("¿No estas cansado? Yo si");
            case 7 -> loadingText.setText(":)");
            case 8 -> loadingText.setText(":(");
            case 9 -> loadingText.setText(">:)");
            case 10 -> loadingText.setText(">:(");
            default -> loadingText.setText("El mejor juego del mundo!");
        }

        loading.setVisible(true);
    }

    private void DisplayMenu() {
        fps.stop();
        resetBoard();
        showMenu();
        GameOverScreen.setVisible(false);
    }

    private void timeRunout() {
        GameOverScreen.setVisible(true);
        Timer timer = new Timer(2000, e -> {
            DisplayMenu();
        });
        timer.setRepeats(false);
        timer.start();
    }

    private void resetBoard() {
        if (activeObjects != null) {
            for (JLabel element: activeObjects.values()) {
                mainBoard.remove(element);
            }
        }

        if (mainBoard != null) {
            remove(mainBoard);
        }
    }

    private void elementsBoard(){
        resetBoard();
        mainUrls = new HashMap<>();
        activeObjects = new HashMap<>();

        mainBoard = new JPanel();
        mainBoard.setBounds(0, 0, screenX, screenY);
        mainBoard.setOpaque(false);
        mainBoard.setLayout(null);

        enemies = 0;
        coins = 0;

        ArrayList<String> allKeys = mainGame.getKeys();

        for (String element : allKeys) {
            int[][] elementInfo = mainGame.objectInformation(element);
            String elementIcon = imagesRute + mainGame.objectIcon(element);
            BufferedImage img;

            try {
                img = ImageIO.read(getClass().getResource(elementIcon));
            } catch (Exception e) {
                img = new BufferedImage(
                    1,
                    1,
                    BufferedImage.TYPE_INT_ARGB
                );
            }

            Image newImage = img.getScaledInstance(elementInfo[1][0], elementInfo[1][1], Image.SCALE_SMOOTH);  
            JLabel newLabel = new JLabel();  
            newLabel.setIcon(new ImageIcon(newImage));  
            newLabel.setBounds(elementInfo[0][0], elementInfo[0][1], elementInfo[1][0], elementInfo[1][1]);

            if (element.equals("player1") && borderA != null) {
                newLabel.setBorder(BorderFactory.createLineBorder(borderA, 2));
            } else if (element.equals("player2") && borderB != null) {
                newLabel.setBorder(BorderFactory.createLineBorder(borderB, 2));
            }

            imageIcons.put(elementIcon, new ImageIcon(newImage)); 
            activeObjects.put(element, newLabel) ;
            mainUrls.put(element, elementIcon);

            mainBoard.add(newLabel);
        }

        for (String element : allKeys) {
            int setLayout = 7;

            if (element.startsWith("player")) {
                setLayout = 1;
            } else if (element.startsWith("enemy")) {
                setLayout = 2;
                enemies += 1;
            } else if (element.startsWith("bomb")) {
                setLayout = 3;
                bombs += 1;
            } else if (element.startsWith("lifeFountain")) {
                setLayout = 4;
                lifeFountains += 1;
            } else if (element.startsWith("coin")) {
                setLayout = 5;
                coins += 1;
            } else if (element.startsWith("safeZone")) {
                setLayout = 6;
            }
            
            mainBoard.setComponentZOrder(activeObjects.get(element), setLayout);
        }

        // GUI
        levelDisplay.setText(mainGame.getLevel() + "/3");
        coinsDisplay.setText("COINS: " + mainGame.collectedCoins());

        int[] deathsInt = mainGame.getDeaths();

        if (!skinB.equals("")) {
            deathsPlayerA.setBounds(5, 5, 250, 30);
            deathsPlayerB.setVisible(true);
            deathsPlayerA.setText("DEATHS PLAYER 1: " + deathsInt[0]);
            deathsPlayerB.setText("DEATHS PLAYER 2: " + deathsInt[1]);
        } else {
            deathsPlayerA.setBounds(5, 20, 140, 30);
            deathsPlayerB.setVisible(false);
            deathsPlayerA.setText("DEATHS: " + deathsInt[0]);
        }
    }

    private void opcionesJugables(){
        playButton.setVisible(false);
        loadButton.setVisible(false);
        soloButton.setVisible(true);
        PvPButton.setVisible(true);
        PvMButton.setVisible(true);
        backButton.setVisible(true);
    }

    private void retrocederMenu(){
        if (gameMode.equals("")) {
            playButton.setVisible(true);
            loadButton.setVisible(true);
            soloButton.setVisible(false);
            PvPButton.setVisible(false);
            PvMButton.setVisible(false);
            backButton.setVisible(false);
        } else {
            gameMode = "";
            skinA = "";
            skinB = "";
            borderA = null;
            borderB = null;
            soloButton.setVisible(true);
            PvPButton.setVisible(true);
            PvMButton.setVisible(true);
            ChooseColor.setVisible(false);
            BlinkySelect.setVisible(false);
            InkySelect.setVisible(false);
            ClydeSelect.setVisible(false);
            selectIndicator.setVisible(false);
        }
        Blinky.setVisible(false);
        Inky.setVisible(false);
        Clyde.setVisible(false);
        RandomMachine.setVisible(false);
        ExpertMachine.setVisible(false);
        EMachine.setVisible(false);
        RMachine.setVisible(false);
    }

    private void characterSelection(){
        soloButton.setVisible(false);
        PvPButton.setVisible(false);
        PvMButton.setVisible(false);
        BlinkySelect.setVisible(true);
        InkySelect.setVisible(true);
        ClydeSelect.setVisible(true);
        Blinky.setVisible(true);
        Inky.setVisible(true);
        Clyde.setVisible(true);

        if (!gameMode.equals("PvP")) {
            selectIndicator.setText("Seleccione su skin");
        } else {
            ChooseColor.setVisible(true);
            selectIndicator.setText("PLAYER 1: Seleccione su skin");
        }
        
        selectIndicator.setVisible(true);
    }

    private void selectColor(){
        Color color = JColorChooser.showDialog(
                null, 
                "Selecciona el color del borde de tu personaje", 
                Color.BLACK
            );

        ChooseColor.setBackground(color);
    }

    private void selectCharacter(String skin){
        if (gameMode.equals("Solo")) {
            skinA = skin;
            startGame(1);
        } else if (gameMode.equals("PvP")) {
            if (ChooseColor.getBackground().equals(Color.BLACK)) {
                JOptionPane.showMessageDialog(null, "Debe escoger algun color!");
                return;
            }
            if (skinA.equals("")) {
                skinA = skin;
                borderA = ChooseColor.getBackground();
                selectIndicator.setText("PLAYER 2: Seleccione su skin");
            } else {
                if (borderA.equals(ChooseColor.getBackground())) {
                    JOptionPane.showMessageDialog(null, "Debe escoger algun color diferente a el color del jugador 1!");
                    return;
                }
                skinB = skin;
                borderB = ChooseColor.getBackground();
                startGame(1);
            }
            ChooseColor.setBackground(Color.BLACK);
        } else if (gameMode.equals("PvM")) {
            if (skinA.equals("")) {
                skinA = skin;
                selectIndicator.setText("Seleccione el tipo de bot");
                BlinkySelect.setVisible(false);
                InkySelect.setVisible(false);
                ClydeSelect.setVisible(false);
                Blinky.setVisible(false);
                Inky.setVisible(false);
                Clyde.setVisible(false);
                RandomMachine.setVisible(true);
                ExpertMachine.setVisible(true);
                EMachine.setVisible(true);
                RMachine.setVisible(true);
            } else {
                skinB = skin;
                startGame(1);
            }
        }
    }

    private void actualizaImagen(String imagenKey){
        JLabel mainLabel = activeObjects.get(imagenKey);

        if (mainLabel != null) {
            int[][] mainInfo = mainGame.objectInformation(imagenKey);
            String imageIcon = imagesRute + mainGame.objectIcon(imagenKey);
            
            if (!imageIcon.equals(mainUrls.get(imagenKey))){
                ImageIcon mainIcon = imageIcons.get(imageIcon);

                if (mainIcon == null) {
                    try {
                        ImageIcon newImage = new ImageIcon(getClass().getResource(imageIcon));
                        ImageIcon newIcon = new ImageIcon(newImage.getImage().getScaledInstance(mainInfo[1][0], mainInfo[1][1], Image.SCALE_SMOOTH));
                        mainIcon = newIcon;
                        imageIcons.put(imageIcon, newIcon);
                    } catch (Exception e) {
                        mainIcon = new ImageIcon(mainUrls.get(imagenKey));
                    }
                }

                mainLabel.setIcon(mainIcon);
                mainUrls.put(imagenKey, imageIcon);
            }

            mainLabel.setBounds(mainInfo[0][0], mainInfo[0][1], mainInfo[1][0], mainInfo[1][1]);
        }
    }

    private void startGame(int level){
        mainMenu.setVisible(false);
        blackBar.setVisible(false);
        loadingScreen();
        Timer timer = new Timer(1000, e -> {
        	try {
        		mainGame.createBoard(skinA, skinB, level, mainFile);
                elementsBoard();
                add(mainBoard); 
                loading.setVisible(false);
                blackBar.setVisible(true);
                fps.start();
        	} catch (GameException ex) {
        		JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        		DisplayMenu();
        	}
        });
        
        setFile();
        timer.setRepeats(false);
        timer.start();
    }

    private void moveBoard(){
        long timerLeft = (mainGame.leftTime() - System.currentTimeMillis()) / 1000;

        if (timerLeft <= 0) {
            fps.stop();
            timeRunout();
            return;
        }
        
        mainGame.move(new int[] {xA, yA}, new int[] {xB, yB});

        actualizaImagen("player1");
        actualizaImagen("player2");

        // ENEMIGOS
        for (int i = 1 ; i <= enemies ; i++) {
            actualizaImagen("enemy" + i);
        }

        // BOMBAS
        for (int i = 1 ; i <= bombs ; i++) {
            actualizaImagen("bomb" + i);
        }

         // FUENTES DE VIDA
        for (int i = 1 ; i <= lifeFountains ; i++) {
            actualizaImagen("lifeFountain" + i);
        }

        // MONEDAS
        for (int i = 1 ; i <= coins ; i++) {
            JLabel coin = activeObjects.get("coin" + i);
            coin.setVisible(!mainGame.coinCollected(i));
        }

        // GUI
        coinsDisplay.setText("COINS: " + mainGame.collectedCoins());
        int[] deathsInt = mainGame.getDeaths();

        if (skinB.equals("")) {
            deathsPlayerA.setText("DEATHS: " + deathsInt[0]);
        } else {
            deathsPlayerA.setText("DEATHS PLAYER 1: " + deathsInt[0]);
            deathsPlayerB.setText("DEATHS PLAYER 2: " + deathsInt[1]);
        }
        
        long minutos = timerLeft / 60;
        long segundos = timerLeft % 60;
        timeLeft.setText(String.format("%d:%02d", minutos, segundos));
    }
}