package dominio;

public class Blue extends Player{
    public Blue(int x, int y, Board board){
        setSize(1.5);
        this.board = board;

        position = new int[] {x - (size[0]/2), y - (size[1]/2)};
        imageIcon = "Player/Blue/";
        mainIcon = imageIcon + "Normal.png";
        velocity = 1.5;
    }
}