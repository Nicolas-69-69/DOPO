package dominio;

public abstract class MovingCharacter extends GameObject {
    protected int[] direction;
    protected String imageIcon;
    protected double velocity = 0;
    
    private void changeIcon(){
        if (imageIcon == null) return; 

        mainIcon = imageIcon;
        if (direction[0] == direction[1] && direction[0] == 0) {
            mainIcon += "Normal";
        } else {
            if (direction[0] == 1) {
                mainIcon += "Right";
            } else if (direction[0] == -1) {
                mainIcon += "Left";
            }
            if (direction[1] == 1) {
                mainIcon += "Down";
            } else if (direction[1] == -1) {
                mainIcon += "Up";
            }
        }

        mainIcon += ".png";
    }

    public void changeDirection(int[] direction) {
        this.direction = direction;
    }

    public void move(){
        if (direction == null) return;
        int increase = (int) (velocity * 3);

        int x = direction[0] * increase;
        int y = direction[1] * increase;

        position[0] += x;
        position[1] += y;

        int wallIndex = 1;

        while (wallIndex > 0) {
            GameObject wall = board.getObject("wall" + wallIndex);
            if (wall == null) break;

            if (Board.isColliding(wall,this)) {
                position[0] -= x;
                position[1] -= y;

                if (this instanceof Basic basic){
                    basic.choca();
                    break;
                } else if (this instanceof Fast fast){
                	fast.choca();
                    break;
                } else {
                    if (x != 0) {
                        for (int i = 0 ; i < increase ; i++) {
                            position[0] += direction[0];
                            if (Board.isColliding(wall,this)) {
                                position[0] -= direction[0];
                                break;
                            }
                        }
                    }
                    if (y != 0) {
                        for (int i = 0 ; i < increase ; i++) {
                            position[1] += direction[1];
                            if (Board.isColliding(wall,this)) {
                                position[1] -= direction[1];
                                break;
                            }
                        }
                    }
                }
            }

            wallIndex += 1;
        }

        changeIcon();
    }
}