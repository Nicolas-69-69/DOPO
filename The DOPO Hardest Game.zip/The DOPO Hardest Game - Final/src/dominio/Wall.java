package dominio;

public class Wall extends GameObject{
    public Wall(int x, int y, int sX, int sY){
        position = new int[] {x, y};
        size = new int[] {sX, sY};
        mainIcon = "Wall.png";
    }

    @Override
    public void action(){}
}