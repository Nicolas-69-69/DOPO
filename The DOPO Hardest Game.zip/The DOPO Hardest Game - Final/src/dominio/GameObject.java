package dominio;

public abstract class GameObject{
    protected int[] position;
    protected int[] size;
    protected String mainIcon = "";
    protected Board board;

    public int[] getPosition(){
        return position;
    }

    public int[] getSize(){
        return size;
    }

    public String getIcon(){
        return mainIcon;
    }

    public abstract void action();
}