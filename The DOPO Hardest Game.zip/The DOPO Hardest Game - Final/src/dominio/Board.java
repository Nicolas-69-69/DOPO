package dominio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.io.*;

public class Board{
    private final int level;
    private final String[] skinsPlayers;
    private final int[][] startPlaces;
    private int neededCoins;
    private long timeLeft, stoppedTime;

    private final Game game;
    private final HashMap<String, GameObject> objects;
    private int coins, walls, bombs, lifeFountain, enemies, safeZones;
    
    private Bot bot;
    private ArrayList<Integer[]> botSpawns;

    private GameObject winner;
    
    private final String[] acceptedSymbols = new String[] {"*",".","↑","↓","→","←","Y","B","G","R","S","E","I"," ","1","2","3","4","<",">","^","v","X","L"};
    
    private void addCoin(int type, int x, int y) {
        coins += 1;
        switch (type) {
            case 2 -> objects.put("coin" + coins, new Skin(x,y,this,"Red"));
            case 3 -> objects.put("coin" + coins, new Skin(x,y,this,"Blue"));
            case 4 -> objects.put("coin" + coins, new Skin(x,y,this,"Green"));
            default -> objects.put("coin" + coins, new Yellow(x,y,this));
        }
    }

    private void addWall(int x, int y, int sX, int sY) {
        walls += 1;
        objects.put("wall" + walls, new Wall(x,y,sX,sY));
    }

    private void addBomb(int x, int y) {
        bombs += 1;
        objects.put("bomb" + bombs, new Bomb(x, y, this));
    }

    private void addLifeFountain(int x, int y) {
        lifeFountain += 1;
        objects.put("lifeFountain" + lifeFountain, new LifeFountain(x, y, this));
    }

    private void addSafeZone(int x, int y, int sX, int sY) {
        safeZones += 1;
        objects.put("safeZone" + safeZones, new SafeZone(x, y, sX, sY, this));
    }

    private void addEnemy(int type, int x, int y, int[] direction) {
        enemies += 1;
        switch (type) {
            case 1 -> objects.put("enemy" + enemies, new Basic(x, y, this, direction));
            case 2 -> objects.put("enemy" + enemies, new Patrol(x, y, this));
            case 3 -> objects.put("enemy" + enemies, new Fast(x, y, this, direction));
        }
    }

    private void addPatrolPoint(Integer[] a) {
        GameObject e = objects.get("enemy" + enemies);
        ((Patrol) e).createPoints(a);
    }

    private void addPlayer(int player, String skin, int x, int y){
        if (skin.equals("")) return;
        if (skin.equals("Expert") || skin.equals("Random")) {
        	if (skin.equals("Random")) {
        		bot = new RandomBot();
        	} else {
        		bot = new ExpertBot(botSpawns, this);
        	}
        	int random = (int) (Math.random() * 3) + 1;
        	if (random == 1) {
        		skin = "Red";
        	} else if (random == 2) {
        		skin = "Blue";
        	} else {
        		skin = "Green";
        	}
        }

        GameObject ply = switch (skin) {
            case "Blue" -> new Blue(x, y, this);
            case "Green" -> new Green(x, y, this);
            case "Red" -> new Red(x, y, this);
            default -> null;
        };

        if (ply == null) return;
        objects.put("player" + player, ply);
    }
    
    private int[] getSizeObject(int x, int y, String[][] cBoard) {
    	int xS = 0, yS = 0;
    	String type = cBoard[x][y];
    	
    	for (int i = y ; i < cBoard[0].length ; i++) {
    		if (!cBoard[x][i].equals(type)) {
    			break;
    		} else {
    			xS += 1;
    		}
    	}
    	
    	for (int i = x ; i < cBoard.length ; i++) {
    		boolean correct = true;
    		for (int j = y ; j < y + xS ; j++) {
    			if (!cBoard[i][j].equals(type)) {
    				correct = false;
    				break;
    			}
    		}
    		if (correct) {
    			yS += 1;
    		} else {
    			break;
    		}
    	}
    	return new int[] {xS, yS};
    }
    
    private Integer[] findItem(String[][] cBoard, String item) {
    	for (int i = 0 ; i < cBoard.length ; i++) {
    		for (int j = 0 ; j < cBoard[0].length ; j++) {
        		if (cBoard[i][j].equals(item)) {
        			return new Integer[] {i,j};
        		}
        	}
    	}
    	return null;
    }
    
    private void findObjects(String[][] cBoard) {
    	botSpawns = new ArrayList<>();
    	Boolean[][] usedObjects = new Boolean[cBoard.length][cBoard[0].length];
    	boolean spawnPoint = false;
    	Integer[] finalSpawn = new Integer[4];
    	ArrayList<Integer[]> saving = new ArrayList<>();

    	for (int index = 0 ; index < usedObjects.length; index++) {
    		for (int j = 0 ; j < usedObjects[index].length ; j++) {
    			usedObjects[index][j] = false;
    		}
    	}
    	
    	for (int i = 0 ; i < usedObjects.length ; i ++) {
    		for (int j = 0 ; j < usedObjects[0].length ; j ++) {
        		if (!usedObjects[i][j]) {
        			usedObjects[i][j] = true;
        			int[] placeO = new int[] {j*30,i*30};
        			if (cBoard[i][j].equals("←")) {
        				addEnemy(1,placeO[0],placeO[1],new int[] {-1,0});
        			} else if (cBoard[i][j].equals("→")) {
        				addEnemy(1,placeO[0],placeO[1],new int[] {1,0});
        			} else if (cBoard[i][j].equals("↓")) {
        				addEnemy(1,placeO[0],placeO[1],new int[] {0,1});
        			} else if (cBoard[i][j].equals("↑")) {
        				addEnemy(1,placeO[0],placeO[1],new int[] {0,-1});
        			} else if (cBoard[i][j].equals("<")) {
        				addEnemy(3,placeO[0],placeO[1],new int[] {-1,0});
        			} else if (cBoard[i][j].equals(">")) {
        				addEnemy(3,placeO[0],placeO[1],new int[] {1,0});
        			} else if (cBoard[i][j].equals("v")) {
        				addEnemy(3,placeO[0],placeO[1],new int[] {0,1});
        			} else if (cBoard[i][j].equals("^")) {
        				addEnemy(3,placeO[0],placeO[1],new int[] {0,-1});
        			} else if (cBoard[i][j].equals("Y")) {
        				addCoin(1,placeO[0] + 5,placeO[1] + 5);
        			} else if (cBoard[i][j].equals("R")) {
        				addCoin(2,placeO[0] + 5,placeO[1] + 5);
        			} else if (cBoard[i][j].equals("G")) {
        				addCoin(4,placeO[0] + 5,placeO[1] + 5);
        			} else if (cBoard[i][j].equals("B")) {
        				addCoin(3,placeO[0] + 5,placeO[1] + 5);
        			} else if (cBoard[i][j].equals("X")) {
        				addBomb(placeO[0],placeO[1]);
        			} else if (cBoard[i][j].equals("L")) {
        				addLifeFountain(placeO[0],placeO[1]);
        			} else if (cBoard[i][j].equals("1")) {
        				addEnemy(2,placeO[0],placeO[1],null);
        				int newI = 1;
        				while (newI > 0) {
        					Integer[] itemInfo = findItem(cBoard,newI + "");
        					if (itemInfo == null) break;
        					addPatrolPoint(new Integer[] {itemInfo[1] * 30, itemInfo[0] * 30});
        					newI += 1;
        				}
        			} else if (cBoard[i][j].equals(".")) {
        				botSpawns.add(new Integer[] {placeO[0],placeO[1]});
        			} else {
        				int[] sizeO = getSizeObject(i,j,cBoard);
        				for (int x = i ; x < i + sizeO[1] ; x++) {
        					for (int y = j ; y < j + sizeO[0] ; y++) {
        						usedObjects[x][y] = true;
            				}
        				}
        				if (cBoard[i][j].equals("*")) {
        					addWall(placeO[0],placeO[1],sizeO[0]*30,sizeO[1]*30);
        				} else if (cBoard[i][j].equals("S")) {
        					if (!spawnPoint) {
        						spawnPoint = true;
        						addSafeZone(placeO[0],placeO[1],sizeO[0]*30,sizeO[1]*30);
        					} else {
        						saving.add(new Integer[] {placeO[0],placeO[1],sizeO[0]*30,sizeO[1]*30});
        					}
        				} else if (cBoard[i][j].equals("E")) {
        					if (finalSpawn[0] == null) {
        						finalSpawn = new Integer[] {placeO[0],placeO[1],sizeO[0]*30,sizeO[1]*30};
        					} else {
        						saving.add(new Integer[] {placeO[0],placeO[1],sizeO[0]*30,sizeO[1]*30});
        					}
        				} else if (cBoard[i][j].equals("I")) {
        					saving.add(new Integer[] {placeO[0],placeO[1],sizeO[0]*30,sizeO[1]*30});
        				}
        			}
        		}
        	}
    	}
    	
    	for (int i = 0 ; i < saving.size() ; i++) {
    		Integer[] info = saving.get(i);
    		addSafeZone(info[0],info[1],info[2],info[3]);
    	}
    	
    	addSafeZone(finalSpawn[0],finalSpawn[1],finalSpawn[2],finalSpawn[3]);
    }
    
    private void createBoard() {
    	String[][] configBoard = new String[23][30];
    	int i = 0;
    	int timeLevel = 5;
    	neededCoins = 0;
    	File file = new File(System.getProperty("user.dir") + "/Configuraciones/Level" + level + ".txt");
    	try (BufferedReader br = new BufferedReader(new FileReader(file))) {
    	    String linea;
    	    while ((linea = br.readLine()) != null) {
    	    	String[] saveDat = linea.split("=");
    	    	if (saveDat[0].equals("NeedCoins")) {
    	    		try {
    	    			neededCoins = Integer.parseInt(saveDat[1]);
            		} catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            			neededCoins = 0;
            		}
    	    	} else if (saveDat[0].equals("Time")) {
    	    		try {
    	    			timeLevel = Integer.parseInt(saveDat[1]);
            		} catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            			timeLevel = 5;
            		}
    	    	} else {
    	    		String[] mainLine = linea.split("");
    	    		for (int j = 0 ; j < 30 ; j++) {
    	    			try {
    	    				configBoard[i][j] = mainLine[j];
    	    			} catch (ArrayIndexOutOfBoundsException e) {
    	    				configBoard[i][j] = "*";
    	    			}
    	    		}
    	    		i += 1 ;
    	    	}
    	    }
    	    for (int index = 0 ; index < configBoard.length; index++) {
        		for (int j = 0 ; j < configBoard[index].length ; j++) {
        			if (configBoard[index][j] == null) {
        				configBoard[index][j] = "*";
        			} else {
        				if (!Arrays.asList(acceptedSymbols).contains(configBoard[index][j])) {
        					configBoard[index][j] = "*";
        				}
        			}
        		}
        	}
    	} catch (IOException | ArrayIndexOutOfBoundsException e) {
    		System.out.println(e);
    	}
    	
    	findObjects(configBoard);
    	startPlaces[1] = ((SafeZone) objects.get("safeZone1")).spawnPoint();
        startPlaces[2] = ((SafeZone) objects.get("safeZone" + safeZones)).spawnPoint();

        timeLeft = System.currentTimeMillis() + (60000 * timeLevel);
    }

    private int getPlayer(GameObject player) {
        if (player == objects.get("player1")) {
            return 1;
        } 
        return 2;
    }

    public static boolean isColliding(GameObject a, GameObject b){
        if (a == null || b == null) return false;
        int[] pA = a.getPosition();
        int[] sA = a.getSize();
        int[] pB = b.getPosition();
        int[] sB = b.getSize();

        return pA[0] < pB[0] + sB[0] &&
           pA[0] + sA[0] > pB[0] &&
           pA[1] < pB[1] + sB[1] &&
           pA[1] + sA[1] > pB[1];
    }

    public Board(int level, String playerA, String playerB, Game game) throws GameException{
        skinsPlayers = new String[3];
        startPlaces = new int[3][2];

        skinsPlayers[1] = playerA;
        skinsPlayers[2] = playerB;

        this.game = game;
        if (level < 1) {
            level = 1;
        } else if (level > 3) {
            level = 3;
        }
        this.level = level;

        objects = new HashMap<>();

        coins = 0;
        walls = 0;
        enemies = 0;
        safeZones = 0;

        createBoard();

        addPlayer(1, playerA, startPlaces[1][0], startPlaces[1][1]);
        addPlayer(2, playerB, startPlaces[2][0], startPlaces[2][1]);
        
        if (objects.get("player1") == null) {
        	throw new GameException(GameException.ERROR_CREATING_GAME);
        }
        
        if (objects.get("player2") == null && !playerB.equals("")) {
        	throw new GameException(GameException.ERROR_CREATING_GAME);
        }

        ((SafeZone) objects.get("safeZone" + safeZones)).setExit(objects.get("player1"));
        ((SafeZone) objects.get("safeZone1")).setExit(objects.get("player2"));
    }

    public void move(int[] directionA, int[] directionB){
        GameObject ply1 = objects.get("player1");
        GameObject ply2 = objects.get("player2");

        MovingCharacter playerA = (MovingCharacter) ply1;
        playerA.changeDirection(directionA);

        if (ply2 != null) {
            MovingCharacter playerB = (MovingCharacter) ply2;
            if (skinsPlayers[2].equals("Expert")) {
            } else if (skinsPlayers[2].equals("Random")) {
            	bot.think();
            	playerB.changeDirection(bot.getDirection());
            } else {
            	playerB.changeDirection(directionB);
            }
        }

        for (String key : new ArrayList<>(objects.keySet())) {
            GameObject object = objects.get(key);
            object.action();
        }
    }

    public void changeCharacter(GameObject player, String skin) {
        int idPlayer = getPlayer(player);
        int[] oldPosition = player.getPosition();
        int[] oldSize = player.getSize();
        
        addPlayer(idPlayer, skin, oldPosition[0] + oldSize[0]/2, oldPosition[1] + oldSize[1]/2);

        ((SafeZone) objects.get("safeZone1")).changeCharacter(player, objects.get("player" + idPlayer));
        ((SafeZone) objects.get("safeZone" + safeZones)).changeCharacter(player, objects.get("player" + idPlayer));

        for (int i = 1 ; i <= coins ; i++ ) {
            ((Coin) objects.get("coin" + i)).changeCharacter(player, objects.get("player" + idPlayer));
        }
    }

    public void resetPlayer(GameObject player){
        int idPlayer = getPlayer(player);
        game.addDeath(idPlayer);
        addPlayer(idPlayer, skinsPlayers[idPlayer], startPlaces[idPlayer][0], startPlaces[idPlayer][1]);
        
        for (int i = 1 ; i <= coins ; i++ ) {
            ((Coin) objects.get("coin" + i)).reset(player);
        }

        ((SafeZone) objects.get("safeZone1")).changeCharacter(player, objects.get("player" + idPlayer));
        ((SafeZone) objects.get("safeZone" + safeZones)).changeCharacter(player, objects.get("player" + idPlayer));
    }

    public void setSpawn(GameObject player, int[] spawnPoint) {
        startPlaces[getPlayer(player)] = spawnPoint;
    }

    public long leftTime(){
        return timeLeft;
    }

    public void stopTimer() {
        stoppedTime = System.currentTimeMillis();
    }

    public void resumeTimer() {
        timeLeft += System.currentTimeMillis() - stoppedTime;
    }

    public GameObject[] getPlayers(){
        return new GameObject[] {objects.get("player1"),objects.get("player2")};
    }

    public ArrayList<GameObject> getSafeZones(){
        ArrayList<GameObject> safe = new ArrayList<>();
        for (int i = 1 ; i <= safeZones ; i++) {
            safe.add(objects.get("safeZone" + i));
        }
        return safe;
    }

    public ArrayList<String> getKeys() {
        ArrayList<String> allKeys = new ArrayList<>();
        for (String key : objects.keySet()) {
            allKeys.add(key);
        }
        return allKeys;
    }

    public int[][] objectInformation(String key){
        GameObject mainObject = objects.get(key);

        if (mainObject != null) {
            return new int[][] {mainObject.getPosition(),mainObject.getSize()};
        } 
        return null;
    }

    public GameObject getObject(String key) {
        return objects.get(key);
    }

    public String objectIcon(String key){
        GameObject mainObject = objects.get(key);
        if (mainObject != null) {
            return mainObject.getIcon();
        } 
        return null;
    }

    public int collectedCoins(){
        int coinsCollected = 0;

        for (int i = 1 ; i <= coins ; i++) {
            GameObject coin = objects.get("coin" + i);

            if (((Coin) coin).coinCollected()) {
                coinsCollected += 1;
            }
        }

        return coinsCollected;
    }

    public void lockCoins(GameObject player) {
        for (int i = 1 ; i <= coins ; i++ ) {
            ((Coin) objects.get("coin" + i)).lock(player);
        }
    }

    public boolean coinCollected(int i) {
        GameObject coin = objects.get("coin" + i);
        if (coin != null) {
            return ((Coin) coin).coinCollected();
        } 
        return false;
    }

    public int needCoins() {
        return neededCoins;
    }

    public int getLevel(){
        return level;
    }

    public boolean completedBoard(){
        return (winner != null);
    }

    public void completeBoard(GameObject winner) {
        this.winner = winner;
    }
}