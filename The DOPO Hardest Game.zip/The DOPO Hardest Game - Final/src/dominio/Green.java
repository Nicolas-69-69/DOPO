package dominio;

public class Green extends Player{
    private int hits;
    private long delay;

    public Green(int x, int y, Board board){
        setSize(1);
        this.board = board;

        position = new int[] {x - (size[0]/2), y - (size[1]/2)};
        imageIcon = "Player/Green/";
        mainIcon = imageIcon + "Normal.png";
        velocity = 1;
        hits = 0;
        delay = 0;
    }

    @Override
    public void damage(){
    	if (shelder) {
    		shelder = false;
    		shelderTime = System.currentTimeMillis() + 2000;
    	} else {
    		if (shelderTime < System.currentTimeMillis()) {
    			if (delay < System.currentTimeMillis()) {
    	            delay = System.currentTimeMillis() + 2000;
    	            if (hits == 0) {
    	                velocity = 0.7;
    	                hits = 1;
    	            } else {
    	                respawn();
    	                velocity = 1;
    	                hits = 0;
    	                delay = 0;
    	            }
    	        }
    		}
    	}
    }
}