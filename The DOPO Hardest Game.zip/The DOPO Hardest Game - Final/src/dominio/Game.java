package dominio;

import java.util.*;
import java.io.*;

public class Game{
    private Board board;
    private final int[] deaths;
    private File file;

    public static int limitX;
    public static int limitY;
    
    private String playerA, playerB;
    
    public void guardaEstado() {
    	if (file == null) return;
    	String borderA  = "", borderB = "";
    	try (BufferedReader br = new BufferedReader(new FileReader(file))) {
    	    String linea;
    	    while ((linea = br.readLine()) != null) {
    	    	String[] saveDat = linea.split("=");
    	        if (saveDat[0].equals("borderA")) {
    	        	borderA = saveDat[1];
    	        } else if (saveDat[0].equals("borderB")) {
    	        	borderB = saveDat[1];
    	        }
    	    }
    	} catch (IOException | ArrayIndexOutOfBoundsException e) {}
    	
    	try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, false))) {
    	    bw.write("level=" + getLevel());
    	    bw.newLine();
    	    bw.write("deathsA=" + deaths[0]);
    	    bw.newLine();
    	    bw.write("deathsB=" + deaths[1]);
    	    bw.newLine();
    	    bw.write("skinA=" + playerA);
    	    bw.newLine();
    	    bw.write("skinB=" + playerB);
    	    bw.newLine();
    	    bw.write("borderA=" + borderA);
    	    bw.newLine();
    	    bw.write("borderB=" + borderB);
    	} catch (IOException e) {}
    }

    public Game(int x, int y){
        limitX = x;
        limitY = y;
        deaths = new int[] {0, 0};
    }
    
    public void setDeaths(int a, int b) {
    	deaths[0] = a;
    	deaths[1] = b;
    }

    public void createBoard(String playerA, String playerB, int level, File file) throws GameException{
    	try {
    		this.playerA = playerA;
    		this.playerB = playerB;
    		board = new Board(level, playerA, playerB , this);
    		this.file = file;
    		guardaEstado();
    	} catch (GameException e) {
    		throw e;
    	}
    }

    public void move(int[] directionA, int[] directionB){
        board.move(directionA,directionB);
    }

    public long leftTime(){
        return board.leftTime();
    }

    public ArrayList<String> getKeys() {
        return board.getKeys();
    }

    public int[][] objectInformation(String key){
        return board.objectInformation(key);
    }

    public String objectIcon(String key){
        return board.objectIcon(key);
    }

    public boolean coinCollected(int i) {
        return board.coinCollected(i);
    }

    public String collectedCoins(){
        return board.collectedCoins() + "/" + board.needCoins();
    }

    public boolean completedBoard(){
        return board.completedBoard();
    }

    public void addDeath(int i){
        deaths[i-1] += 1;
        guardaEstado();
    }

    public int[] getDeaths(){
        return deaths;
    }

    public int getLevel(){
        return board.getLevel();
    }

    public void stopTimer(){
        board.stopTimer();
    }

    public void resumeTimer() {
        board.resumeTimer();
    }
}