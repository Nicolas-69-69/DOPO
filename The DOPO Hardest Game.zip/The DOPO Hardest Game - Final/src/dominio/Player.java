package dominio;

public abstract class Player extends MovingCharacter{
	protected boolean shelder = false;
	protected long shelderTime;

    protected void setSize(double i) {
        int newSize = (int) (30 * i);
        size = new int[] {newSize,newSize};
    }

    public void respawn() {
        this.board.resetPlayer(this);
    }

    public void damage(){
    	if (shelder) {
    		shelder = false;
    		shelderTime = System.currentTimeMillis() + 2000;
    	} else {
    		if (shelderTime < System.currentTimeMillis()) {
    			respawn();
    		}
    	}
    }
    
    public void activeShelder() {
    	shelder = true;
    }

    @Override
    public void action(){
        move();
        boolean isSafe = false;

        for (GameObject elem : board.getSafeZones()) {
            if (Board.isColliding(this, elem)) {
                isSafe = true;
                break;
            }
        }
        if (isSafe) return;
        GameObject[] players = this.board.getPlayers();
        if (Board.isColliding(players[0],players[1])){
            if (players[0] == this) {
                ((Player) players[1]).respawn();
            } else {
                ((Player) players[0]).respawn();
            }
            respawn();
        } 
    }
}