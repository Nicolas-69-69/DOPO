package dominio;

public abstract class Bot {
	protected int[] direction;
	
	public int[] getDirection() {
		return direction;
	}
	
	public abstract void think();
}
