package dominio;

public class LifeFountain extends GameObject{
    private boolean used;

    public LifeFountain(int x, int y, Board board){
        this.board = board;
        size = new int[] {30, 30};
        position = new int[] {x, y};
        mainIcon = "Milk/Normal.png";
        used = false;
    }

    private void destroy() {
        used = true;
        mainIcon = "Milk/Empty.png";
    }

    @Override
    public void action(){
        if (used) return;
        GameObject[] players = this.board.getPlayers();
        if (Board.isColliding(players[0],this)){
            destroy();
            ((Player) players[0]).activeShelder();
        } else if (Board.isColliding(players[1],this)){
            destroy();
            ((Player) players[1]).activeShelder();
        }
    }
}