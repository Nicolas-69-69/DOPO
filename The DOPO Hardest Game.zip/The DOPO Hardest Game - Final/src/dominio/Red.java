package dominio;

public class Red extends Player{
    public Red(int x, int y, Board board){
        setSize(1);
        this.board = board;

        position = new int[] {x - (size[0]/2), y - (size[1]/2)};
        imageIcon = "Player/Red/";
        mainIcon = imageIcon + "Normal.png";
        velocity = 1;
    }
}