package dominio;

public class Fast extends Enemy{
    public Fast(int x, int y, Board board, int[] direction){
        setSize(1);
        position = new int[] {x, y};
        velocity = 2;
        this.board = board;
        this.direction = direction;
        imageIcon = "Enemy/";
        mainIcon = imageIcon + "Normal.png";
    }

    public void choca(){
        direction[0] *= -1;
        direction[1] *= -1;
    }
}