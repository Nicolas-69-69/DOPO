package dominio;

import java.util.ArrayList;
import java.util.Arrays;

public class Patrol extends Enemy{
    private ArrayList<Integer[]> allDots;
    private Integer[] step;
    private int place;

    public Patrol(int x, int y, Board board) {
        setSize(1);
        position = new int[] {x, y};
        velocity = 1;
        place = -1;
        this.board = board;
        direction = new int[] {0,0};
        imageIcon = "Enemy/";
        mainIcon = imageIcon + "Normal.png";
        allDots = new ArrayList<>();
    }

    public void createPoints(Integer[] dot) {
        allDots.add(dot);
    }

    @Override
    public void action() {
        if (allDots == null) return;
        if (step == null)  step = new Integer[] {position[0], position[1]};
        if (Arrays.equals(position, new int[] {step[0],step[1]})) {
            place += 1;
            if (place >= allDots.size()) place = 0;
            step = allDots.get(place);

            if (step[0] < position[0]) {
                direction[0] = -1;
            } else if (step[0] > position[0]) {
                direction[0] = 1;
            }

            if (step[1] < position[1]) {
                direction[1] = -1;
            } else if (step[1] > position[1]) {
                direction[1] = 1;
            }
        }

        if (direction[0] == -1 && position[0] < step[0]) {
            direction[0] = 0;
            position[0] = step[0];
        } else if (direction[0] == 1 && position[0] > step[0]) {
            direction[0] = 0;
            position[0] = step[0];
        }

        if (direction[1] == -1 && position[1] < step[1]) {
            direction[1] = 0;
            position[1] = step[1];
        } else if (direction[1] == 1 && position[1] > step[1]) {
            direction[1] = 0;
            position[1] = step[1];
        }

        mainAction();
    }
}