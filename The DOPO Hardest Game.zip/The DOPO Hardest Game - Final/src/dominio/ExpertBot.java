package dominio;

import java.util.ArrayList;

public class ExpertBot extends Bot{
	private final ArrayList<Integer[]> spots;
	private final Board board;
	
	public ExpertBot(ArrayList<Integer[]> spots, Board board) {
		this.board = board;
		this.spots = spots;
		direction = new int[] {0,0};
 	}
	
	public double distance(int[] a, Integer[] b) {
		int xD = b[0] - a[0];
		int yD = b[1] - a[1];
		
		return Math.sqrt((xD*xD)+(yD*yD));
	}
	
	@Override
	public void think() {
		GameObject player = board.getObject("player2");
		if (player == null) return;
		
		int[] playerP = player.getPosition();
		double nearD = 1000;
		int iFinal = -1;
		
		for (int i = 0 ; i < spots.size() ; i++) {
			double dis = distance(playerP, spots.get(i));
			if (dis < nearD) {
				iFinal = i;
				nearD = dis;
			}
		}
		
		if (iFinal >= 0) {
			Integer[] place = spots.get(iFinal);
			if (playerP[0] < place[0]) {
				direction[0] = 1;
			} else if (playerP[0] > place[0]) {
				direction[0] = -1;
			} else {
				direction[0] = 0;
			}
		}
	}
}
