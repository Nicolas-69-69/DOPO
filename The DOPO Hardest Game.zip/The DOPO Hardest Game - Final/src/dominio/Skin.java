package dominio;

public class Skin extends Coin{
    private final String skin;

    public Skin(int x, int y, Board board, String skin){
        this.board = board;
        this.skin = skin;
        position = new int[] {x,y};
        size = new int[] {20, 20};
        locked = false;
        mainIcon = "Coin/" + skin + ".png";
    }

    @Override
    public void action(){
        if (coinCollected()) return;
        collect();
        if (player == null) return;
        board.changeCharacter(player, skin);
    }
}