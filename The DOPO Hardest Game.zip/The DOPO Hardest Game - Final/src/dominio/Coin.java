package dominio;

public abstract class Coin extends GameObject{
    protected boolean locked;
    protected GameObject player;

    protected void collect(){
        GameObject[] players = this.board.getPlayers();
        
        if (Board.isColliding(players[0],this)){
            this.player = players[0];
        } else if (Board.isColliding(players[1],this)){
            this.player = players[1];
        }
    }

    public boolean coinCollected(){
        return player != null;
    }

    public void lock(GameObject player){
        if (this.player == null) return;
        if (player == this.player) locked = true;
    }

    public void reset(GameObject player){
        if (locked) return;
        if (player != this.player) return;
        this.player = null;
    }

    public void changeCharacter(GameObject player, GameObject newPlayer) {
        if (this.player == player) {
            this.player = newPlayer;
        }
    }

    @Override
    public void action(){
        if (coinCollected()) return;
        collect();
    }
}