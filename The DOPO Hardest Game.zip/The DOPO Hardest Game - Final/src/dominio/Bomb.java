package dominio;

public class Bomb extends GameObject{
    private boolean exploted;
    public Bomb(int x, int y, Board board){
        this.board = board;
        size = new int[] {30, 30};
        position = new int[] {x, y};
        mainIcon = "Bomb/Normal.png";
        exploted = false;
    }

    private void destroy() {
        exploted = true;
        mainIcon = "Bomb/Exploted.png";
    }

    @Override
    public void action(){
        if (exploted) return;
        GameObject[] players = this.board.getPlayers();
        if (Board.isColliding(players[0],this)){
            ((Player) players[0]).respawn();
            destroy();
            return;
        } else if (Board.isColliding(players[1],this)){
            ((Player) players[1]).respawn();
            destroy();
            return;
        }

        int index = 1;

        while (index > 0) {
            GameObject enemy = board.getObject("enemy" + index);

            if (enemy == null) break;

            if (Board.isColliding(enemy, this)) {
                ((Enemy) enemy).destroy();
                destroy();
                return;
            }

            index += 1;
        }
    }
}