package dominio;

public class Basic extends Enemy{
    public Basic(int x, int y, Board board, int[] direction){
        setSize(1);
        position = new int[] {x, y};
        velocity = 1;
        this.board = board;
        this.direction = direction;
        imageIcon = "Enemy/";
        mainIcon = imageIcon + "Normal.png";
    }

    public void choca(){
        direction[0] *= -1;
        direction[1] *= -1;
    }
}