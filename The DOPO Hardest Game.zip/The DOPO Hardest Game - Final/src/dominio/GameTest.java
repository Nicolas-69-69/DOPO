package dominio;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.*;

class GameTest {

	@Test
    void shouldCreatePlayerInCorrectPosition() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        int[][] information = game.objectInformation("player1");

        assertArrayEquals(new int[][] {{120,325},{30,30}},information);
    }
	
	@Test
    void shouldMovePlayerRight() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        game.move(new int[] {1,0}, null);

        int[][] information = game.objectInformation("player1");

        assertEquals(123, information[0][0]);
        assertEquals(325, information[0][1]);
    }
	
	@Test
    void shouldMovePlayerLeft() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        game.move(new int[] {-1,0}, null);

        int[][] information = game.objectInformation("player1");

        assertEquals(117, information[0][0]);
        assertEquals(325, information[0][1]);
    }
	
	@Test
    void shouldMovePlayerUp() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        game.move(new int[] {0,-1}, null);

        int[][] information = game.objectInformation("player1");

        assertEquals(120, information[0][0]);
        assertEquals(322, information[0][1]);
    }
	
	@Test
    void shouldMovePlayerDown() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        game.move(new int[] {0,1}, null);

        int[][] information = game.objectInformation("player1");

        assertEquals(120, information[0][0]);
        assertEquals(328, information[0][1]);
    }
	
	@Test
    void shouldReturnExistingObjects() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        assertNotNull(game.objectInformation("player1"));
        assertNotNull(game.objectInformation("coin1"));
        assertNotNull(game.objectInformation("enemy1"));
    }
	
	@Test
    void shouldIncreaseDeaths() {
        Game game = new Game(900,690);

        game.addDeath(1);
        game.addDeath(1);

        int[] deaths = game.getDeaths();

        assertEquals(2, deaths[0]);
        assertEquals(0, deaths[1]);
    }
	
	@Test
    void shouldReturnCorrectCollectedCoinsFormat() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        assertEquals("0/1", game.collectedCoins());
    }

    @Test
    void shouldReturnKeys() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        assertFalse(game.getKeys().isEmpty());
    }
    
    @Test
    void shouldReturnObjectIcon() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        assertNotNull(game.objectIcon("player1"));
    }

    @Test
    void shouldReturnPositiveTime() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        assertTrue(game.leftTime() > 0);
    }
    
    @Test
    void shouldPauseAndResumeTimer() {
        Game game = new Game(900,690);

        try {
        	game.createBoard("Red", "", 1, new File("Test.txt"));
        } catch (GameException e) {
        	fail("No deberia lanzar excepcion: " + e.getMessage());
        }

        game.stopTimer();
        game.resumeTimer();

        assertTrue(game.leftTime() > 0);
    }
}
