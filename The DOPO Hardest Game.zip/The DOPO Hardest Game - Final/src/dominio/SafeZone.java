package dominio;

import java.util.ArrayList;

public class SafeZone extends GameObject{
    private GameObject playerExit;
    private final ArrayList<GameObject> playersColliding;

    public SafeZone(int x, int y, int sX, int sY, Board board){
        playersColliding = new ArrayList<>();
        position = new int[] {x, y};
        size = new int[] {sX, sY};
        this.board = board;
        mainIcon = "SafeZone.png";
    }

    private void touchingPlayer(GameObject player){
        if (playerExit == null) {
            if (playersColliding.contains(player)) return;
            playersColliding.add(player);
            board.setSpawn(player, spawnPoint());
            board.lockCoins(player);
        } else {
            if (board.collectedCoins() == board.needCoins() && playerExit == player) {
                board.completeBoard(player);
            }
        }
    }

    public void changeCharacter(GameObject player, GameObject newPlayer) {
        if (playerExit == player) {
            playerExit = newPlayer;
        }
    }

    public void setExit(GameObject playerExit){
        this.playerExit = playerExit;
    }

    public int[] spawnPoint(){
        return new int[] {position[0] + (size[0]/2), position[1] + (size[1]/2)};
    }

    @Override
    public void action(){
        GameObject[] players = this.board.getPlayers();
        if (Board.isColliding(players[0],this)){
            touchingPlayer(players[0]);
        }
        if (Board.isColliding(players[1],this)){
            touchingPlayer(players[1]);
        } 
    }
}