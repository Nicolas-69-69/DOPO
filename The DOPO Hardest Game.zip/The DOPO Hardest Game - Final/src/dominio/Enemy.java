package dominio;

public abstract class Enemy extends MovingCharacter{
    protected boolean destroyed = false;

    protected void setSize(double i) {
        int newSize = (int) (30 * i);
        size = new int[] {newSize,newSize};
    }

    protected void mainAction() {
        if (destroyed) return;
        move();
        GameObject[] players = this.board.getPlayers();
        if (Board.isColliding(players[0],this)){
            ((Player) players[0]).damage();
        } else if (Board.isColliding(players[1],this)){
            ((Player) players[1]).damage();
        }
    }

    public int[] getDirection(){
        return direction;
    }

    public void destroy() {
        mainIcon = imageIcon + "Destroyed.png";
        destroyed = true;
    }

    @Override
    public void action() {
        mainAction();
    }
}