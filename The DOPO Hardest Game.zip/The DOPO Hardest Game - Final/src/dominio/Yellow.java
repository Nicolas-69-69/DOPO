package dominio;

public class Yellow extends Coin{
    public Yellow(int x, int y, Board board){
        this.board = board;
        position = new int[] {x,y};
        size = new int[] {20, 20};
        locked = false;
        mainIcon = "Coin/Yellow.png";
    }
}