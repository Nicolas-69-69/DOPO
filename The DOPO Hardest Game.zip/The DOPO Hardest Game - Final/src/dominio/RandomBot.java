package dominio;

public class RandomBot extends Bot{
	public long newMove;
	
	public RandomBot() {
		direction = new int[] {0,0};
 	}
	
	@Override
	public void think() {
		if (newMove < System.currentTimeMillis()) {
			newMove = System.currentTimeMillis() + 1000;
			direction[0] = ((int) (Math.random() * 3)) - 1;
			direction[1] = ((int) (Math.random() * 3)) - 1;
        }
	}
}