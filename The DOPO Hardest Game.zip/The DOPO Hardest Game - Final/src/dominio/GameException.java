package dominio;

public class GameException extends Exception{
    public static final String ERROR_FILE = "Hubo un error abriendo con el archivo";
    public static final String ERROR_CREATING_GAME = "Error al crear el tablero, vuelvalo a intentar";
    public static final String CORRUPTED_FILE = "El archivo fue corrompido, porfavor eliga otro";

    public GameException(String message) {
        super(message);
    }
}